

<?php $__env->startSection('title', 'Checkout Pesanan | TERRAWOOD'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .checkout-page {
        background: #F7F5EF;
        min-height: 100vh;
        padding: 55px 6%;
        color: #293747;
    }

    .checkout-container {
        max-width: 1100px;
        margin: auto;
    }

    .checkout-back {
        display: inline-block;
        margin-bottom: 25px;
        color: #082744;
        text-decoration: none;
        font-weight: 700;
        transition: color .25s ease;
    }

    .checkout-back:hover {
        color: #C47A1B;
    }

    .checkout-heading {
        margin-bottom: 28px;
    }

    .checkout-heading h1 {
        color: #082744;
        font-size: 32px;
        margin: 0 0 8px;
    }

    .checkout-heading p {
        color: #718096;
        margin: 0;
        line-height: 1.7;
    }

    .checkout-grid {
        display: grid;
        grid-template-columns: 1.1fr .9fr;
        gap: 25px;
        align-items: start;
    }

    .checkout-card {
        background: white;
        border: 1px solid #E9E5DC;
        border-radius: 16px;
        padding: 28px;
        box-shadow: 0 10px 30px rgba(8, 39, 68, .04);
    }

    .checkout-card h2 {
        color: #082744;
        font-size: 20px;
        margin: 0 0 23px;
    }

    .form-group {
        margin-bottom: 19px;
    }

    .form-group label {
        display: block;
        color: #293747;
        font-size: 14px;
        font-weight: 700;
        margin-bottom: 9px;
    }

    .form-group input,
    .form-group textarea {
        width: 100%;
        box-sizing: border-box;
        border: 1px solid #DDD9D0;
        background: #FFFEFC;
        border-radius: 9px;
        padding: 13px 15px;
        font-size: 14px;
        outline: none;
        font-family: inherit;
        transition: border-color .2s, box-shadow .2s;
    }

    .form-group input:focus,
    .form-group textarea:focus {
        border-color: #F5A623;
        box-shadow: 0 0 0 3px rgba(245,166,35,.12);
    }

    .form-group textarea {
        min-height: 115px;
        resize: vertical;
        line-height: 1.6;
    }

    .form-group input[readonly] {
        background: #F1F0EC;
        color: #718096;
        cursor: not-allowed;
    }

    .form-error {
        color: #B42318;
        font-size: 12px;
        margin-top: 6px;
    }

    .product-summary {
        display: flex;
        gap: 17px;
        align-items: center;
        margin-bottom: 24px;
    }

    .summary-image {
        width: 105px;
        height: 105px;
        flex-shrink: 0;
        border-radius: 11px;
        overflow: hidden;
        background: #EEEAE2;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #718096;
        font-size: 12px;
        text-align: center;
    }

    .summary-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    .summary-info {
        min-width: 0;
    }

    .summary-info h3 {
        color: #082744;
        font-size: 17px;
        margin: 0 0 7px;
    }

    .summary-info p {
        color: #718096;
        font-size: 13px;
        margin: 0 0 7px;
    }

    .summary-info strong {
        color: #B47A13;
        font-size: 15px;
    }

    .price-row {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        padding: 14px 0;
        border-bottom: 1px solid #EEEAE2;
        font-size: 14px;
    }

    .price-row span:first-child {
        color: #718096;
    }

    .price-row strong {
        color: #082744;
        text-align: right;
    }

    .total-row {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        padding-top: 20px;
        margin-top: 5px;
        color: #082744;
        font-weight: 800;
        font-size: 17px;
    }

    .total-price {
        color: #B47A13;
        font-size: 21px;
        text-align: right;
    }

    .checkout-submit {
        width: 100%;
        border: none;
        background: #F5A623;
        color: #082744;
        border-radius: 10px;
        padding: 16px;
        font-size: 15px;
        font-weight: 800;
        cursor: pointer;
        margin-top: 25px;
        transition: all .25s ease;
    }

    .checkout-submit:hover {
        background: #E99A15;
        transform: translateY(-2px);
        box-shadow: 0 8px 18px rgba(245,166,35,.2);
    }

    .checkout-submit:active {
        transform: translateY(0);
    }

    .checkout-note {
        color: #718096;
        font-size: 12px;
        line-height: 1.7;
        margin-top: 15px;
    }

    .checkout-alert {
        padding: 14px 17px;
        border-radius: 10px;
        margin-bottom: 20px;
        font-size: 14px;
        line-height: 1.6;
    }

    .checkout-alert.error {
        background: #FFE2E2;
        color: #B42318;
        border: 1px solid #F5BABA;
    }

    .checkout-alert.success {
        background: #DDF5E6;
        color: #237344;
        border: 1px solid #B8E5C8;
    }

    .checkout-alert ul {
        padding-left: 20px;
    }

    @media(max-width: 800px) {
        .checkout-grid {
            grid-template-columns: 1fr;
        }
    }

    @media(max-width: 550px) {
        .checkout-page {
            padding: 35px 5%;
        }

        .checkout-heading h1 {
            font-size: 26px;
        }

        .checkout-card {
            padding: 20px;
        }

        .product-summary {
            align-items: flex-start;
        }

        .summary-image {
            width: 85px;
            height: 85px;
        }

        .total-row {
            font-size: 15px;
        }

        .total-price {
            font-size: 18px;
        }
    }
</style>

<div class="checkout-page">
    <div class="checkout-container">

        <a href="<?php echo e(route('catalog.show', $product->slug)); ?>"
           class="checkout-back">
            ← Kembali ke Detail Produk
        </a>

        <div class="checkout-heading">
            <h1>Checkout Pesanan</h1>
            <p>
                Lengkapi informasi pengiriman untuk melanjutkan
                pesanan Anda bersama TERRAWOOD.
            </p>
        </div>

        
        <?php if($errors->any()): ?>
            <div class="checkout-alert error">
                <strong>Periksa kembali data pesanan:</strong>
                <ul style="margin-bottom:0;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="checkout-alert error">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="checkout-alert success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('account.orders.store', $product->slug)); ?>"
              method="POST"
              id="checkoutForm">

            <?php echo csrf_field(); ?>

            <div class="checkout-grid">

                
                <div class="checkout-card">

                    <h2>Informasi Pemesan</h2>

                    <div class="form-group">
                        <label>Nama Customer</label>
                        <input type="text"
                               value="<?php echo e(auth()->user()->name); ?>"
                               readonly>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email"
                               value="<?php echo e(auth()->user()->email); ?>"
                               readonly>
                    </div>

                    <div class="form-group">
                        <label>Nomor WhatsApp *</label>
                        <input type="tel"
                               name="customer_phone"
                               value="<?php echo e(old('customer_phone')); ?>"
                               placeholder="Contoh: 081234567890"
                               maxlength="20"
                               required>

                        <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Jumlah Produk *</label>
                        <input type="number"
                               id="quantity"
                               name="quantity"
                               min="1"
                               max="100"
                               value="<?php echo e(old('quantity', 1)); ?>"
                               required>

                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Alamat Pengiriman *</label>
                        <textarea name="shipping_address"
                                  placeholder="Masukkan alamat lengkap pengiriman..."
                                  required><?php echo e(old('shipping_address')); ?></textarea>

                        <?php $__errorArgs = ['shipping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label>Catatan Tambahan (Opsional)</label>
                        <textarea name="notes"
                                  placeholder="Contoh: Patokan rumah atau permintaan khusus..."><?php echo e(old('notes')); ?></textarea>

                        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                
                <div class="checkout-card">

                    <h2>Ringkasan Pesanan</h2>

                    <div class="product-summary">

                        <div class="summary-image">

                            <?php if($product->image): ?>
                                <img
                                    src="<?php echo e(\Illuminate\Support\Facades\Storage::url($product->image)); ?>"
                                    alt="<?php echo e($product->name); ?>"
                                >
                            <?php else: ?>
                                Tidak ada gambar
                            <?php endif; ?>

                        </div>

                        <div class="summary-info">
                            <h3><?php echo e($product->name); ?></h3>

                            <p>
                                <?php echo e($product->category?->name ?? 'Furnitur'); ?>

                            </p>

                            <strong>
                                Rp <?php echo e(number_format((float) $product->price, 0, ',', '.')); ?>

                            </strong>
                        </div>

                    </div>

                    <div class="price-row">
                        <span>Harga Satuan</span>

                        <strong>
                            Rp <?php echo e(number_format((float) $product->price, 0, ',', '.')); ?>

                        </strong>
                    </div>

                    <div class="price-row">
                        <span>Jumlah Produk</span>

                        <strong id="quantityDisplay">
                            <?php echo e(old('quantity', 1)); ?>

                        </strong>
                    </div>

                    <div class="total-row">
                        <span>Total Pesanan</span>

                        <span class="total-price" id="totalDisplay">
                            Rp 0
                        </span>
                    </div>

                    <button type="submit"
                            class="checkout-submit"
                            id="submitButton">
                        Buat Pesanan Sekarang
                    </button>

                    <p class="checkout-note">
                        * Pesanan akan tercatat dengan status Menunggu.
                        Admin TERRAWOOD akan memproses pesanan Anda.
                        Biaya pengiriman akan dikonfirmasi oleh admin.
                    </p>

                </div>

            </div>

        </form>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const quantityInput = document.getElementById('quantity');
    const quantityDisplay = document.getElementById('quantityDisplay');
    const totalDisplay = document.getElementById('totalDisplay');
    const checkoutForm = document.getElementById('checkoutForm');

    const unitPrice = <?php echo e((float) $product->price); ?>;

    function formatRupiah(value) {
        return 'Rp ' + new Intl.NumberFormat('id-ID', {
            maximumFractionDigits: 0
        }).format(value);
    }

    function updateTotal() {

        let quantity = parseInt(quantityInput.value);

        if (isNaN(quantity)) {
            quantity = 1;
        }

        quantity = Math.min(100, Math.max(1, quantity));

        quantityDisplay.textContent = quantity;

        totalDisplay.textContent = formatRupiah(
            unitPrice * quantity
        );
    }

    quantityInput.addEventListener('input', updateTotal);

    quantityInput.addEventListener('change', function () {

        let quantity = parseInt(this.value);

        if (isNaN(quantity)) {
            quantity = 1;
        }

        quantity = Math.min(100, Math.max(1, quantity));

        this.value = quantity;

        updateTotal();
    });

    checkoutForm.addEventListener('submit', function (event) {

        const quantity = parseInt(quantityInput.value);

        if (isNaN(quantity) || quantity < 1 || quantity > 100) {
            event.preventDefault();

            quantityInput.value = 1;
            updateTotal();

            quantityInput.focus();

            return;
        }
    });

    updateTotal();

});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\terrawood\resources\views/account/checkout.blade.php ENDPATH**/ ?>