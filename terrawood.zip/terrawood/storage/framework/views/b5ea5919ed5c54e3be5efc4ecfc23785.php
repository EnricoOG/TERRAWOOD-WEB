

<?php
    $contact = array_merge([
        'whatsapp'  => '6281234567890',
        'phone'     => '+62 812 3456 7890',
        'phone_raw' => '+6281234567890',
        'email'     => 'info@terrawood.id',
        'address'   => 'Indonesia',
    ], (array) config('terrawood', []));
?>

<?php if (! $__env->hasRenderedOnce('e2ef78b0-243b-4ba9-b2a9-1ecfe3760978')): $__env->markAsRenderedOnce('e2ef78b0-243b-4ba9-b2a9-1ecfe3760978'); ?>
<?php $__env->startPush('styles'); ?>
<style>
:root {
    --tw-dark: #061D33;
    --tw-orange: #FFA43A;
}

.footer,
.footer *,
.footer *::before,
.footer *::after { box-sizing: border-box; }

.footer { font-family: 'Inter', sans-serif; }

.footer h3 { font-family: 'Manrope', sans-serif; }

.footer a,
.whatsapp-float { text-decoration: none; }

.footer a:focus-visible,
.whatsapp-float:focus-visible {
    outline: 2px solid var(--tw-orange);
    outline-offset: 3px;
}

/* =====================================
   FOOTER
===================================== */

.footer {
    background: var(--tw-dark);
    color: white;
    padding: 60px 7% 23px;
}

.footer-grid {
    display: grid;
    grid-template-columns: 1.3fr 1fr 1fr 1.2fr;
    gap: 40px;
    padding-bottom: 40px;
}

.footer-brand {
    display: flex;
    align-items: center;
}

.footer-logo {
    width: 175px;
    height: 70px;
    object-fit: contain;
    object-position: left center;
}

.footer-about p {
    color: rgba(255,255,255,.8);
    font-size: 13px;
    line-height: 1.9;
    margin-top: 16px;
    max-width: 260px;
}

.footer-column h3 {
    color: white;
    font-size: 15px;
    margin-bottom: 20px;
    font-weight: 800;
}

.footer-column a,
.footer-column p {
    display: block;
    color: rgba(255,255,255,.8);
    font-size: 13px;
    line-height: 2.5;
    transition: color .3s ease, transform .3s ease;
}

.footer-column a:hover {
    color: var(--tw-orange);
    transform: translateX(4px);
}

.footer-bottom {
    border-top: 1px solid rgba(255,255,255,.2);
    padding-top: 22px;
    display: flex;
    justify-content: space-between;
    gap: 15px;
    color: rgba(255,255,255,.75);
    font-size: 12px;
}

/* =====================================
   WHATSAPP BUTTON
===================================== */

.whatsapp-float {
    position: fixed;
    right: 22px;
    bottom: 22px;
    width: 58px;
    height: 58px;
    border-radius: 50%;
    background: #20C76A;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 5px 18px rgba(0,0,0,.2);
    z-index: 90;
    -webkit-tap-highlight-color: transparent;
    transition: transform .35s cubic-bezier(.22,.61,.36,1), box-shadow .35s cubic-bezier(.22,.61,.36,1);
}

.whatsapp-float:hover {
    transform: translateY(-4px) scale(1.05);
    color: white;
    box-shadow: 0 10px 24px rgba(0,0,0,.25);
}

.whatsapp-float:active {
    transform: scale(.95);
}

@media(max-width: 1100px) {
    .footer-grid { grid-template-columns: repeat(2, 1fr); }
}

@media(max-width: 760px) {
    .footer {
        padding: 44px 6% calc(22px + env(safe-area-inset-bottom, 0px));
    }

    .footer-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 28px 20px;
        padding-bottom: 30px;
    }

    .footer-about,
    .footer-column:last-child { grid-column: 1 / -1; }

    .footer-about p { max-width: none; }

    .footer-column h3 {
        margin-bottom: 8px;
        font-size: 14px;
    }

    .footer-column a,
    .footer-column p { line-height: 2.2; }

    .footer-bottom {
        flex-direction: column;
        align-items: center;
        gap: 6px;
        text-align: center;
    }

    .whatsapp-float {
        right: 16px;
        bottom: calc(16px + env(safe-area-inset-bottom, 0px));
        width: 54px;
        height: 54px;
    }
}

@media (hover: none) {
    .footer-column a:hover { transform: none; }
}

@media(max-width: 340px) {
    .footer-grid { grid-template-columns: 1fr; }
}
</style>
<?php $__env->stopPush(); ?>
<?php endif; ?>



<footer class="footer" id="kontak">

    <div class="footer-grid">

        <div class="footer-about">

            <div class="footer-brand">

                <img
                    src="<?php echo e(asset('images/terrawood-logo.png')); ?>"
                    alt="TERRAWOOD - Crafting Comfort with Nature"
                    class="footer-logo"
                    width="175"
                    height="70"
                    loading="lazy"
                    decoding="async"
                >

            </div>

            <p>
                Furniture yang menginspirasi, untuk hidup yang lebih baik.
                Menghadirkan kenyamanan dan keindahan dalam setiap ruang.
            </p>

        </div>


        <div class="footer-column">

            <h3>Navigasi</h3>

            <a href="<?php echo e(route('home')); ?>">Beranda</a>
            <a href="<?php echo e(route('catalog.index')); ?>">Katalog Produk</a>
            <a href="<?php echo e(route('services.index')); ?>">Layanan</a>
            <a href="<?php echo e(route('home')); ?>#tentang">Tentang Kami</a>
            <a href="<?php echo e(route('articles.index')); ?>">Artikel</a>
            <a href="<?php echo e(route('portfolios.index')); ?>">Portofolio</a>

        </div>


        <div class="footer-column">

            <h3>Layanan Kami</h3>

            <a href="<?php echo e(route('services.index')); ?>">
                Lihat Semua Layanan
            </a>

            <a href="<?php echo e(route('portfolios.index')); ?>">
                Hasil Proyek Kami
            </a>

            <a href="<?php echo e(route('home')); ?>#mitra">
                Kerja Sama
            </a>

        </div>


        <div class="footer-column">

            <h3>Kontak Kami</h3>

            <a href="tel:<?php echo e($contact['phone_raw']); ?>">📞 <?php echo e($contact['phone']); ?></a>
            <a href="mailto:<?php echo e($contact['email']); ?>">✉ <?php echo e($contact['email']); ?></a>
            <p>📍 <?php echo e($contact['address']); ?></p>

        </div>

    </div>


    <div class="footer-bottom">

        <span>
            © <?php echo e(date('Y')); ?> TERRAWOOD. All rights reserved.
        </span>

        <span>
            Crafting Comfort with Nature.
        </span>

    </div>

</footer>




<a
    href="https://wa.me/<?php echo e($contact['whatsapp']); ?>"
    class="whatsapp-float"
    target="_blank"
    rel="noopener"
    aria-label="Hubungi TERRAWOOD melalui WhatsApp"
>

    <svg
        viewBox="0 0 32 32"
        width="31"
        height="31"
        aria-hidden="true"
    >
        <path
            fill="currentColor"
            d="M16.02 3.2A12.7 12.7 0 0 0 5.1 22.38L3.4 28.6l6.37-1.67A12.7 12.7 0 1 0 16.02 3.2Zm0 23.1c-1.98 0-3.92-.53-5.62-1.53l-.4-.24-3.78.99 1.01-3.68-.26-.42a10.38 10.38 0 1 1 9.05 4.88Zm5.7-7.77c-.31-.16-1.84-.91-2.12-1.01-.29-.1-.5-.16-.71.16-.21.31-.81 1.01-.99 1.22-.18.21-.36.23-.67.08-.31-.16-1.3-.48-2.47-1.53-.91-.81-1.53-1.81-1.71-2.12-.18-.31-.02-.48.14-.64.14-.14.31-.36.47-.54.16-.18.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.71-.97-2.34-.26-.61-.52-.53-.71-.54h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.07-1.1 2.61s1.13 3.03 1.28 3.24c.16.21 2.22 3.39 5.38 4.75.75.32 1.33.51 1.78.65.75.24 1.44.2 1.98.12.6-.09 1.84-.75 2.1-1.48.26-.73.26-1.35.18-1.48-.08-.13-.29-.21-.6-.37Z"
        />
    </svg>

</a><?php /**PATH C:\laragon\www\terrawood\resources\views/partials/footer.blade.php ENDPATH**/ ?>