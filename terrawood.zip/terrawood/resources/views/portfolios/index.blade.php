@extends('layouts.app')

@section('title', 'Portofolio | TERRAWOOD')

@section('content')

<style>
.portfolio-page {
    min-height: 100vh;
    background: #F7F5EF;
    color: #293747;
    font-family: 'Inter', sans-serif;
}

.portfolio-hero {
    background: #082744;
    padding: 100px 6% 85px;
    color: white;
    text-align: center;
}

.portfolio-hero span {
    color: #F5A623;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 3px;
    text-transform: uppercase;
}

.portfolio-hero h1 {
    font-family: 'Playfair Display', serif;
    font-size: clamp(36px, 5vw, 58px);
    margin: 18px 0;
}

.portfolio-hero p {
    max-width: 650px;
    margin: auto;
    color: #D5DEE6;
    line-height: 1.8;
    font-size: 15px;
}

.portfolio-container {
    max-width: 1250px;
    width: 88%;
    margin: auto;
    padding: 75px 0;
}

.portfolio-heading {
    margin-bottom: 35px;
}

.portfolio-heading span {
    color: #C47A1B;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 2px;
}

.portfolio-heading h2 {
    font-family: 'Playfair Display', serif;
    font-size: 34px;
    margin: 10px 0;
}

.portfolio-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 28px;
}

.portfolio-card {
    background: white;
    border-radius: 13px;
    overflow: hidden;
    box-shadow: 0 8px 28px rgba(8, 39, 68, .07);
    transition: .3s ease;
}

.portfolio-card:hover {
    transform: translateY(-7px);
    box-shadow: 0 15px 35px rgba(8, 39, 68, .13);
}

.portfolio-image {
    height: 245px;
    background: #E8E4DA;
    overflow: hidden;
}

.portfolio-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: .5s ease;
}

.portfolio-card:hover .portfolio-image img {
    transform: scale(1.06);
}

.portfolio-content {
    padding: 23px;
}

.portfolio-category {
    color: #C47A1B;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.portfolio-content h3 {
    font-size: 20px;
    margin: 10px 0;
    color: #082744;
}

.portfolio-client {
    color: #7A8490;
    font-size: 13px;
    margin-bottom: 13px;
}

.portfolio-description {
    color: #687481;
    font-size: 13px;
    line-height: 1.8;
}

.portfolio-date {
    border-top: 1px solid #EEEAE2;
    margin-top: 18px;
    padding-top: 15px;
    color: #87909A;
    font-size: 12px;
}

.portfolio-featured {
    display: inline-block;
    background: #FFF2D8;
    color: #A66A12;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 700;
    margin-top: 12px;
}

.portfolio-empty {
    text-align: center;
    background: white;
    border-radius: 12px;
    padding: 55px 20px;
    color: #7A8490;
    grid-column: 1 / -1;
}

.portfolio-cta {
    background: #082744;
    color: white;
    padding: 55px 25px;
    text-align: center;
    border-radius: 15px;
    margin-top: 75px;
}

.portfolio-cta h2 {
    font-family: 'Playfair Display', serif;
    font-size: 30px;
    margin-bottom: 12px;
}

.portfolio-cta p {
    color: #D5DEE6;
    margin-bottom: 25px;
}

.portfolio-cta a {
    display: inline-block;
    background: #F5A623;
    color: #082744;
    padding: 13px 27px;
    border-radius: 5px;
    text-decoration: none;
    font-weight: 700;
    font-size: 13px;
}

@media (max-width: 900px) {
    .portfolio-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 600px) {
    .portfolio-hero {
        padding: 75px 6%;
    }

    .portfolio-grid {
        grid-template-columns: 1fr;
    }

    .portfolio-container {
        width: 90%;
        padding: 50px 0;
    }
}
</style>

<div class="portfolio-page">

    <section class="portfolio-hero">
        <span>Our Portfolio</span>
        <h1>Every Space Has a Story.</h1>
        <p>
            Jelajahi berbagai proyek furnitur dan dekorasi TERRAWOOD
            yang dirancang untuk menghadirkan kenyamanan, keindahan,
            dan karakter pada setiap ruang.
        </p>
    </section>

    <section class="portfolio-container">

        <div class="portfolio-heading">
            <span>OUR PROJECTS</span>
            <h2>Hasil Karya TERRAWOOD</h2>
            <p>Beberapa proyek yang telah kami kerjakan.</p>
        </div>

        <div class="portfolio-grid">

            @forelse ($portfolios as $portfolio)

                <article class="portfolio-card">

                    <div class="portfolio-image">
                        @if ($portfolio->image)
                            <img
                                src="{{ asset('storage/' . $portfolio->image) }}"
                                alt="{{ $portfolio->title }}"
                            >
                        @else
                            <img
                                src="https://placehold.co/800x550/F0EDE5/082744?text=TERRAWOOD"
                                alt="TERRAWOOD Portfolio"
                            >
                        @endif
                    </div>

                    <div class="portfolio-content">

                        <span class="portfolio-category">
                            {{ $portfolio->category ?: 'Furniture & Decoration' }}
                        </span>

                        <h3>{{ $portfolio->title }}</h3>

                        @if ($portfolio->client_name)
                            <div class="portfolio-client">
                                Client: {{ $portfolio->client_name }}
                            </div>
                        @endif

                        <p class="portfolio-description">
                            {{ \Illuminate\Support\Str::limit($portfolio->description, 120) }}
                        </p>

                        @if ($portfolio->project_date)
                            <div class="portfolio-date">
                                Project Date:
                                {{ $portfolio->project_date->format('d F Y') }}
                            </div>
                        @endif

                        @if ($portfolio->is_featured)
                            <span class="portfolio-featured">
                                FEATURED PROJECT
                            </span>
                        @endif

                    </div>
                </article>

            @empty

                <div class="portfolio-empty">
                    <h3>Belum Ada Portofolio</h3>
                    <p>
                        Portofolio proyek TERRAWOOD akan ditampilkan
                        di halaman ini.
                    </p>
                </div>

            @endforelse

        </div>

        <div style="margin-top: 35px;">
            {{ $portfolios->links() }}
        </div>

        <div class="portfolio-cta">
            <h2>Let's Create Something Beautiful.</h2>
            <p>
                Wujudkan ruang impian bersama solusi furnitur
                dan dekorasi dari TERRAWOOD.
            </p>
            <a href="{{ route('catalog.index') }}">
                Explore Our Collection
            </a>
        </div>

    </section>

</div>

@endsection
