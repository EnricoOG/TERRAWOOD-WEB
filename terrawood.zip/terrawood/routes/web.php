<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\CustomerOrderController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\PublicPageController;

use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\ArticleController;
use App\Http\Controllers\Admin\PortfolioController;
use App\Http\Controllers\Admin\PartnerController;

use App\Http\Controllers\TestimonialController;
use App\Http\Controllers\OrderController;

// ==========================================
// HALAMAN PUBLIK
// ==========================================

Route::get('/', [HomeController::class, 'index'])
    ->name('home');

Route::get('/katalog', [CatalogController::class, 'index'])
    ->name('catalog.index');

Route::get('/katalog/{slug}', [CatalogController::class, 'show'])
    ->name('catalog.show');

// Halaman Layanan dan Portofolio
Route::get('/layanan', [PublicPageController::class, 'services'])
    ->name('services.index');

Route::get('/portofolio', [PublicPageController::class, 'portfolios'])
    ->name('portfolios.index');

Route::get('/artikel', [PublicPageController::class, 'articles'])->name('articles.index');
Route::get('/artikel/{slug}', [PublicPageController::class, 'showArticle'])->name('articles.show');


// ==========================================
// AUTENTIKASI CUSTOMER DAN ADMIN
// ==========================================

Route::get('/register', [AuthController::class, 'showRegister'])
    ->name('register');

Route::post('/register', [AuthController::class, 'register'])
    ->name('register.store');

Route::get('/login', [AuthController::class, 'showLogin'])
    ->name('login');

Route::post('/login', [AuthController::class, 'login'])
    ->name('login.store');

Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');


// ==========================================
// HALAMAN CUSTOMER
// ==========================================

Route::middleware(['auth', 'role:user'])
    ->prefix('account')
    ->name('account.')
    ->group(function () {

        Route::get('/', [AccountController::class, 'index'])
            ->name('index');

        // Checkout Customer
        Route::get('/checkout/{slug}', [CustomerOrderController::class, 'create'])
            ->name('orders.create');

        Route::post('/checkout/{slug}', [CustomerOrderController::class, 'store'])
            ->name('orders.store');

        // Detail dan pembatalan pesanan
        Route::get('/orders/{id}', [AccountController::class, 'showOrder'])
            ->whereNumber('id')
            ->name('orders.show');

        Route::post('/orders/{id}/cancel', [CustomerOrderController::class, 'cancel'])
            ->whereNumber('id')
            ->name('orders.cancel');

        // Notifikasi
        Route::post('/notifications/{id}/read', [AccountController::class, 'readNotification'])
            ->name('notifications.read');

        Route::get('/notifications/status', [AccountController::class, 'notificationStatus'])
            ->name('notifications.status');

        
    });



// ==========================================
// HALAMAN ADMIN
// ==========================================

Route::middleware(['auth', 'role:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        // Dashboard
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])
            ->name('dashboard');

        // CRUD Produk
        Route::resource('products', ProductController::class);

        // CRUD Kategori
        Route::resource('categories', CategoryController::class);

        // CRUD Layanan
        Route::resource('services', ServiceController::class);

        // CRUD Artikel
        Route::resource('articles', ArticleController::class);

        // CRUD Portofolio
        Route::resource('portfolios', PortfolioController::class);

        // CRUD Mitra
        Route::resource('partners', PartnerController::class);

        // CRUD Testimoni
        Route::resource('testimonials', TestimonialController::class);

        // CRUD Pesanan
        Route::resource('orders', OrderController::class);
    });
