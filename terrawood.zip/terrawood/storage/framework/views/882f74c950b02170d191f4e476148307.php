<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'TERRAWOOD | Crafting Comfort with Nature'); ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/terrawood-mark.png')); ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,500;1,600&display=swap" rel="stylesheet">

    <style>
        :root {
            --navy: #082744;
            --navy-dark: #061D33;
            --gold: #F5A623;
            --gold-light: #FFA43A;
            --ivory: #F7F5EF;
            --charcoal: #293747;

            --font-heading: 'Manrope', sans-serif;
            --font-body: 'Inter', sans-serif;
            --font-editorial: 'Playfair Display', serif;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--font-body);
            color: var(--charcoal);
            background: var(--ivory);
        }

        h1, h2, h3, h4 {
            font-family: var(--font-heading);
        }

        a {
            text-decoration: none;
        }

        button {
            font-family: var(--font-body);
        }

        /* =====================================
           BADGE NOTIFIKASI (dipakai di navbar & tombol cadangan)
        ===================================== */

        .js-notification-badge[hidden] {
            display: none !important;
        }

        /* =====================================
           TOMBOL PROFIL & NOTIFIKASI CADANGAN
           (hanya tampil di halaman yang BELUM memakai
            partial navbar; otomatis disembunyikan jika sudah)
        ===================================== */

        .global-notification {
            position: fixed;
            top: 22px;
            right: 25px;
            z-index: 99999;

            width: 46px;
            height: 46px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            background: var(--navy);
            color: var(--gold);

            border: 2px solid rgba(255,255,255,.35);
            border-radius: 50%;

            box-shadow: 0 5px 18px rgba(0,0,0,.15);

            font-family: var(--font-heading);
            font-size: 14px;
            font-weight: 800;
            letter-spacing: .5px;
            line-height: 1;

            -webkit-tap-highlight-color: transparent;

            transition: background .3s ease,
                        color .3s ease,
                        transform .3s ease,
                        box-shadow .3s ease;
        }

        @media (hover: hover) {
            .global-notification:hover {
                background: var(--navy-dark);
                color: var(--gold);
                transform: translateY(-2px) scale(1.06);
                box-shadow: 0 8px 22px rgba(8,39,68,.25);
            }
        }

        .global-notification:active {
            transform: scale(.94);
        }

        .global-notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;

            min-width: 19px;
            height: 19px;
            padding: 0 4px;

            display: flex;
            align-items: center;
            justify-content: center;

            background: #E53935;
            color: white;

            border: 2px solid var(--ivory);
            border-radius: 20px;

            font-family: var(--font-body);
            font-size: 10px;
            font-weight: 800;
            line-height: 1;
        }

        /* =====================================
           NOTIFICATION TOAST
        ===================================== */

        .notification-toast {
            position: fixed;
            top: 90px;
            right: 25px;
            z-index: 100000;

            width: min(360px, calc(100% - 40px));
            padding: 20px;

            background: var(--navy);
            color: white;

            border-radius: 14px;
            box-shadow: 0 12px 35px rgba(0,0,0,.2);

            animation: notificationSlide .35s ease;
        }

        .notification-toast-title {
            color: var(--gold);
            font-family: var(--font-heading);
            font-size: 13px;
            font-weight: 800;
            margin-bottom: 8px;
            padding-right: 22px;
        }

        .notification-toast-message {
            color: white;
            font-size: 12px;
            line-height: 1.7;
            margin-bottom: 12px;
        }

        .notification-toast-link {
            color: var(--gold);
            font-size: 12px;
            font-weight: 700;
        }

        .notification-toast-link:hover {
            color: white;
        }

        .notification-toast-close {
            position: absolute;
            top: 10px;
            right: 13px;

            border: none;
            background: transparent;
            color: white;

            font-size: 19px;
            cursor: pointer;
        }

        @keyframes notificationSlide {
            from {
                opacity: 0;
                transform: translateY(-12px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .notification-toast {
                animation: none;
            }
        }

        /* =====================================
           RESPONSIVE
        ===================================== */

        /* Di HP, tombol cadangan dipindah ke kanan bawah agar tidak menutupi menu */
        @media(max-width: 900px) {
            .global-notification {
                top: auto;
                right: 16px;
                bottom: calc(86px + env(safe-area-inset-bottom, 0px));
                width: 44px;
                height: 44px;
                font-size: 13px;
            }

            .notification-toast {
                top: 82px;
                left: 15px;
                right: 15px;
                width: auto;
            }
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

    

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'user' && empty($hasSiteNavbar)): ?>

            <?php
                $globalUnreadCount = auth()->user()
                    ->unreadNotifications()
                    ->count();

                $globalInitials = '';

                $globalWords = preg_split(
                    '/\s+/',
                    trim((string) auth()->user()->name),
                    -1,
                    PREG_SPLIT_NO_EMPTY
                ) ?: [];

                foreach (array_slice($globalWords, 0, 2) as $globalWord) {
                    $globalInitials .= mb_strtoupper(mb_substr($globalWord, 0, 1));
                }

                if ($globalInitials === '') {
                    $globalInitials = 'U';
                }
            ?>

            <a
                href="<?php echo e(route('account.index')); ?>#notifications"
                class="global-notification"
                id="globalNotificationLink"
                data-status-url="<?php echo e(route('account.notifications.status')); ?>"
                data-order-base="<?php echo e(url('/account/orders')); ?>"
                title="Profil dan Notifikasi"
                aria-label="Profil dan Notifikasi"
            >

                <?php echo e($globalInitials); ?>


                <!-- Notification Badge -->
                <span
                    class="global-notification-badge js-notification-badge"
                    id="globalNotificationBadge"
                    <?php if($globalUnreadCount <= 0): ?> hidden <?php endif; ?>
                ><?php echo e($globalUnreadCount > 9 ? '9+' : $globalUnreadCount); ?></span>

            </a>

        <?php endif; ?>
    <?php endif; ?>


    

    <?php echo $__env->yieldContent('content'); ?>


    

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'user'): ?>

            <script>
                document.addEventListener('DOMContentLoaded', function () {

                    /*
                    Sumber data notifikasi:
                    - navbar baru  -> elemen #navProfile
                    - tombol cadangan -> elemen #globalNotificationLink
                    */

                    const profileLink =
                        document.getElementById('globalNotificationLink') ||
                        document.getElementById('navProfile');

                    if (!profileLink || !profileLink.dataset.statusUrl) return;

                    let latestNotificationId = null;
                    let firstCheck = true;

                    /*
                    =====================================
                    SHOW NOTIFICATION POPUP
                    =====================================
                    */

                    function showNotificationToast(notification) {

                        const toast = document.createElement('div');

                        toast.className = 'notification-toast';

                        const closeButton = document.createElement('button');

                        closeButton.className = 'notification-toast-close';
                        closeButton.type = 'button';
                        closeButton.setAttribute('aria-label', 'Tutup notifikasi');
                        closeButton.textContent = '×';

                        closeButton.addEventListener('click', function () {
                            toast.remove();
                        });

                        const title = document.createElement('div');

                        title.className = 'notification-toast-title';
                        title.textContent = 'Pembaruan Pesanan TERRAWOOD';

                        const message = document.createElement('p');

                        message.className = 'notification-toast-message';
                        message.textContent = notification.message ||
                            'Ada pembaruan pesanan Anda.';

                        toast.appendChild(closeButton);
                        toast.appendChild(title);
                        toast.appendChild(message);

                        if (notification.order_id && profileLink.dataset.orderBase) {

                            const link = document.createElement('a');

                            link.className = 'notification-toast-link';

                            link.href = profileLink.dataset.orderBase + '/' +
                                encodeURIComponent(notification.order_id);

                            link.textContent = 'Lihat Detail Pesanan →';

                            toast.appendChild(link);
                        }

                        document.body.appendChild(toast);

                        setTimeout(function () {
                            toast.remove();
                        }, 7000);
                    }


                    /*
                    =====================================
                    UPDATE SEMUA BADGE (navbar & cadangan)
                    =====================================
                    */

                    function updateBadges(count) {

                        document.querySelectorAll('.js-notification-badge')
                            .forEach(function (badge) {

                                if (count > 0) {

                                    badge.textContent = count > 9 ? '9+' : count;
                                    badge.hidden = false;

                                } else {

                                    badge.hidden = true;

                                }

                            });
                    }


                    /*
                    =====================================
                    CHECK NOTIFICATIONS
                    =====================================
                    */

                    async function checkNotifications() {

                        /* Hemat permintaan saat tab tidak aktif */
                        if (document.hidden && !firstCheck) return;

                        try {

                            const response = await fetch(
                                profileLink.dataset.statusUrl,
                                {
                                    headers: {
                                        'Accept': 'application/json'
                                    },
                                    credentials: 'same-origin'
                                }
                            );

                            if (!response.ok) return;

                            const data = await response.json();

                            /*
                            UPDATE BADGE
                            */

                            updateBadges(Number(data.unread_count) || 0);

                            /*
                            FIRST CHECK
                            */

                            if (firstCheck) {

                                latestNotificationId =
                                    data.latest?.id ?? null;

                                firstCheck = false;

                                return;
                            }

                            /*
                            DETECT NEW NOTIFICATION
                            */

                            if (
                                data.latest &&
                                data.latest.id !== latestNotificationId
                            ) {

                                latestNotificationId = data.latest.id;

                                showNotificationToast(data.latest);
                            }

                        } catch (error) {

                            console.error(
                                'Gagal memeriksa notifikasi:',
                                error
                            );

                        }
                    }


                    /*
                    =====================================
                    RUN NOTIFICATION CHECK
                    =====================================
                    */

                    checkNotifications();

                    setInterval(checkNotifications, 10000);

                    /* Periksa segera saat tab kembali aktif */
                    document.addEventListener('visibilitychange', function () {

                        if (!document.hidden) {
                            checkNotifications();
                        }

                    });

                });
            </script>

        <?php endif; ?>
    <?php endif; ?>


    

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH C:\laragon\www\terrawood\resources\views/layouts/app.blade.php ENDPATH**/ ?>