

<?php $__env->startSection('title', 'Katalog Produk | TERRAWOOD'); ?>

<?php $__env->startSection('content'); ?>

<?php
    /* =====================================
       IKON (SVG)
    ===================================== */
    $ic = [
        'search' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
        'x'      => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
        'arrow'  => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
        'image'  => '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
    ];

    $icon = function ($name, $size = 18) use ($ic) {
        return '<svg class="cat-ic" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($ic[$name] ?? '') . '</svg>';
    };

    $waIcon = '<svg class="cat-ic" width="18" height="18" viewBox="0 0 32 32" aria-hidden="true"><path fill="currentColor" d="M16.02 3.2A12.7 12.7 0 0 0 5.1 22.38L3.4 28.6l6.37-1.67A12.7 12.7 0 1 0 16.02 3.2Zm0 23.1c-1.98 0-3.92-.53-5.62-1.53l-.4-.24-3.78.99 1.01-3.68-.26-.42a10.38 10.38 0 1 1 9.05 4.88Zm5.7-7.77c-.31-.16-1.84-.91-2.12-1.01-.29-.1-.5-.16-.71.16-.21.31-.81 1.01-.99 1.22-.18.21-.36.23-.67.08-.31-.16-1.3-.48-2.47-1.53-.91-.81-1.53-1.81-1.71-2.12-.18-.31-.02-.48.14-.64.14-.14.31-.36.47-.54.16-.18.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.71-.97-2.34-.26-.61-.52-.53-.71-.54h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.07-1.1 2.61s1.13 3.03 1.28 3.24c.16.21 2.22 3.39 5.38 4.75.75.32 1.33.51 1.78.65.75.24 1.44.2 1.98.12.6-.09 1.84-.75 2.1-1.48.26-.73.26-1.35.18-1.48-.08-.13-.29-.21-.6-.37Z"/></svg>';

    /* =====================================
       WHATSAPP (nomor diatur di config/terrawood.php)
    ===================================== */
    $waNumber = config('terrawood.whatsapp', '6281234567890');

    $waProductUrl = function ($productName) use ($waNumber) {
        return 'https://wa.me/' . $waNumber . '?text='
             . rawurlencode('Halo TERRAWOOD, saya tertarik dengan produk "' . $productName . '". Apakah masih tersedia?');
    };

    /* =====================================
       FILTER & URL
    ===================================== */
    $searchTerm = trim((string) ($search ?? ''));
    $sortValue  = $sort ?? null;

    $hasFilters = $searchTerm !== '' || filled($categoryId ?? null);

    /* Parameter yang dipertahankan saat memilih kategori (pencarian & urutan) */
    $queryWithoutCategory = collect(request()->query())
        ->except(['page', 'category'])
        ->filter(function ($value) { return filled($value); })
        ->all();

    $queryWithoutSearch = collect(request()->query())
        ->except(['page', 'search'])
        ->filter(function ($value) { return filled($value); })
        ->all();

    $categoryUrl = function ($id = null) use ($queryWithoutCategory) {
        $query = $queryWithoutCategory;

        if ($id) {
            $query['category'] = $id;
        }

        return route('catalog.index', $query);
    };

    $activeCategory = $categories->firstWhere('id', $categoryId ?? null);
?>

<?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .catalog-page,
    .catalog-page *,
    .catalog-page *::before,
    .catalog-page *::after { box-sizing: border-box; }

    .catalog-page {
        --c-navy: #082744;
        --c-gold: #F5A623;
        --c-orange: #FFA43A;
        --c-ivory: #F7F5EF;
        --c-text: #293747;
        --c-muted: #718096;
        --c-line: #E9E5DC;
        --c-amber: #B47A13;
        --c-ease: cubic-bezier(.22, .61, .36, 1);

        min-height: 70vh;
        padding: 36px 6% 80px;
        background: var(--c-ivory);
        color: var(--c-text);
        font-family: 'Inter', sans-serif;
    }

    .catalog-container {
        max-width: 1300px;
        margin: 0 auto;
    }

    .catalog-page a { text-decoration: none; }

    .catalog-page a:focus-visible,
    .catalog-page button:focus-visible,
    .catalog-page select:focus-visible {
        outline: 2px solid var(--c-gold);
        outline-offset: 3px;
    }

    .cat-ic { display: block; flex-shrink: 0; }

    /* =====================================
       HERO
    ===================================== */

    .catalog-hero {
        position: relative;
        overflow: hidden;
        padding: 44px 48px;
        margin-bottom: 28px;
        border-radius: 20px;
        background: linear-gradient(115deg, #082744, #123e63);
        color: white;
        box-shadow: 0 14px 32px rgba(8,39,68,.14);
    }

    .catalog-hero::before,
    .catalog-hero::after {
        content: "";
        position: absolute;
        border-radius: 50%;
        pointer-events: none;
    }

    .catalog-hero::before {
        right: -90px;
        top: -130px;
        width: 320px;
        height: 320px;
        border: 1px solid rgba(245,166,35,.28);
    }

    .catalog-hero::after {
        right: 60px;
        bottom: -110px;
        width: 200px;
        height: 200px;
        border: 1px solid rgba(255,255,255,.1);
    }

    .catalog-hero > * {
        position: relative;
        z-index: 1;
    }

    .breadcrumb {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 18px;
        color: #B9C6D3;
        font-size: 12.5px;
    }

    .breadcrumb a {
        color: #D6E0E9;
        transition: color .25s ease;
    }

    .breadcrumb a:hover { color: var(--c-gold); }

    .breadcrumb [aria-current] {
        color: var(--c-gold);
        font-weight: 700;
    }

    .catalog-hero h1 {
        margin: 0 0 12px;
        font-size: clamp(30px, 4vw, 42px);
        font-weight: 800;
        line-height: 1.15;
    }

    .catalog-hero h1 span { color: var(--c-gold); }

    .catalog-hero p {
        max-width: 620px;
        margin: 0;
        color: #D6E0E9;
        font-size: 15px;
        line-height: 1.75;
    }

    /* =====================================
       PENCARIAN & URUTAN
    ===================================== */

    .catalog-tools {
        display: flex;
        align-items: stretch;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 18px;
    }

    .catalog-search {
        display: flex;
        flex: 1;
        gap: 10px;
        min-width: 240px;
    }

    .search-field {
        position: relative;
        flex: 1;
        min-width: 0;
    }

    .search-field > .cat-ic {
        position: absolute;
        left: 17px;
        top: 50%;
        transform: translateY(-50%);
        color: #9AA3AE;
        pointer-events: none;
    }

    .search-field input {
        width: 100%;
        height: 50px;
        padding: 0 46px 0 47px;
        border: 1.5px solid #E2DED5;
        border-radius: 999px;
        background: white;
        color: var(--c-text);
        font-family: inherit;
        font-size: 14px;
        transition: border-color .25s ease, box-shadow .25s ease;
    }

    .search-field input:focus {
        border-color: var(--c-gold);
        box-shadow: 0 0 0 4px rgba(245,166,35,.15);
        outline: none;
    }

    .search-clear {
        position: absolute;
        right: 10px;
        top: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        color: #9AA3AE;
        transform: translateY(-50%);
        transition: background-color .2s ease, color .2s ease;
    }

    .search-clear:hover {
        background: #F1EDE3;
        color: var(--c-navy);
    }

    .catalog-submit {
        height: 50px;
        padding: 0 26px;
        border: 0;
        border-radius: 999px;
        background: var(--c-gold);
        color: var(--c-navy);
        font-family: 'Manrope', 'Inter', sans-serif;
        font-size: 13px;
        font-weight: 800;
        cursor: pointer;
        -webkit-tap-highlight-color: transparent;
        transition: background-color .3s var(--c-ease), color .3s var(--c-ease), transform .3s var(--c-ease);
    }

    .catalog-submit:active {
        transform: scale(.96);
        transition-duration: .12s;
    }

    @media (hover: hover) {
        .catalog-submit:hover {
            background: var(--c-navy);
            color: white;
        }
    }

    .catalog-sort select {
        min-width: 195px;
        height: 50px;
        padding: 0 44px 0 20px;
        border: 1.5px solid #E2DED5;
        border-radius: 999px;
        background: white url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23082744' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E") no-repeat right 16px center / 14px;
        color: var(--c-navy);
        font-family: inherit;
        font-size: 13.5px;
        font-weight: 600;
        cursor: pointer;
        -webkit-appearance: none;
        appearance: none;
        transition: border-color .25s ease;
    }

    .catalog-sort select:hover { border-color: var(--c-gold); }

    /* =====================================
       CHIP KATEGORI
    ===================================== */

    .category-chips {
        position: relative;
        display: flex;
        gap: 8px;
        padding: 4px 2px 10px;
        margin-bottom: 6px;
        overflow-x: auto;
        scrollbar-width: none;
        -webkit-overflow-scrolling: touch;
    }

    .category-chips::-webkit-scrollbar { display: none; }

    .chip {
        flex: 0 0 auto;
        padding: 10px 18px;
        border: 1.5px solid #E3DDCF;
        border-radius: 999px;
        background: white;
        color: var(--c-muted);
        font-size: 13px;
        font-weight: 700;
        white-space: nowrap;
        -webkit-tap-highlight-color: transparent;
        transition:
            background-color .25s var(--c-ease),
            color .25s var(--c-ease),
            border-color .25s var(--c-ease),
            transform .25s var(--c-ease);
    }

    .chip:active {
        transform: scale(.96);
        transition-duration: .12s;
    }

    .chip.active {
        border-color: var(--c-navy);
        background: var(--c-navy);
        color: white;
    }

    @media (hover: hover) {
        .chip:not(.active):hover {
            border-color: var(--c-gold);
            color: var(--c-navy);
        }
    }

    /* =====================================
       INFO HASIL & FILTER AKTIF
    ===================================== */

    .catalog-meta {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
        margin: 18px 0 22px;
    }

    .result-count {
        margin: 0;
        color: var(--c-muted);
        font-size: 14px;
    }

    .result-count strong { color: var(--c-navy); }

    .filter-tags {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
    }

    .filter-tag {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 8px 6px 13px;
        border-radius: 999px;
        background: #FFF3DC;
        color: #8A5600;
        font-size: 12px;
        font-weight: 700;
    }

    .filter-tag a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: rgba(138,86,0,.12);
        color: #8A5600;
        transition: background-color .2s ease, color .2s ease;
    }

    .filter-tag a:hover {
        background: #8A5600;
        color: white;
    }

    .filter-reset {
        color: var(--c-amber);
        font-size: 12.5px;
        font-weight: 800;
        transition: color .25s ease;
    }

    .filter-reset:hover { color: var(--c-navy); }

    /* =====================================
       GRID & KARTU PRODUK
    ===================================== */

    .product-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 22px;
    }

    .product-card {
        position: relative;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        border: 1px solid var(--c-line);
        border-radius: 16px;
        background: white;
        box-shadow: 0 2px 10px rgba(8,39,68,.04);
        -webkit-tap-highlight-color: transparent;
        transition:
            transform .35s var(--c-ease),
            box-shadow .35s var(--c-ease),
            border-color .35s var(--c-ease);
    }

    .product-card:active {
        transform: scale(.985);
        transition-duration: .12s;
    }

    .product-image {
        position: relative;
        height: 230px;
        overflow: hidden;
        background: #ECE9E1;
    }

    .product-image img {
        width: 100%;
        height: 100%;
        padding: 14px;
        object-fit: contain;
        transition: transform .5s var(--c-ease);
    }

    .product-no-image {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 8px;
        height: 100%;
        color: #9AA3AE;
        font-size: 13px;
    }

    .product-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        z-index: 1;
        padding: 5px 11px;
        border-radius: 999px;
        background: var(--c-gold);
        color: var(--c-navy);
        font-size: 11px;
        font-weight: 800;
        letter-spacing: .4px;
    }

    .product-info {
        display: flex;
        flex: 1;
        flex-direction: column;
        padding: 18px;
    }

    .product-category {
        color: var(--c-amber);
        font-size: 11.5px;
        font-weight: 800;
        letter-spacing: .7px;
        text-transform: uppercase;
    }

    .product-info h3 {
        display: -webkit-box;
        min-height: 2.8em;
        margin: 8px 0;
        overflow: hidden;
        color: var(--c-navy);
        font-size: 16px;
        font-weight: 800;
        line-height: 1.4;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }

    .product-description {
        display: -webkit-box;
        flex: 1;
        margin-bottom: 14px;
        overflow: hidden;
        color: var(--c-muted);
        font-size: 13px;
        line-height: 1.6;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }

    .product-bottom {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 14px;
    }

    .product-price {
        color: var(--c-navy);
        font-family: 'Manrope', sans-serif;
        font-size: 18px;
        font-weight: 800;
        line-height: 1.2;
    }

    .product-price.is-ask {
        color: var(--c-amber);
        font-size: 14px;
    }

    .product-wa {
        position: relative;
        z-index: 2;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: #E8F8EF;
        color: #1B9B52;
        -webkit-tap-highlight-color: transparent;
        transition: background-color .3s var(--c-ease), color .3s var(--c-ease), transform .3s var(--c-ease);
    }

    .product-wa:active {
        transform: scale(.92);
        transition-duration: .12s;
    }

    @media (hover: hover) {
        .product-wa:hover {
            background: #20C76A;
            color: white;
        }
    }

    .product-button {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 12px;
        border-radius: 999px;
        background: var(--c-navy);
        color: white;
        font-family: 'Manrope', 'Inter', sans-serif;
        font-size: 13px;
        font-weight: 800;
        transition: background-color .3s var(--c-ease), color .3s var(--c-ease);
    }

    .product-button .cat-ic { transition: transform .3s var(--c-ease); }

    /* Membuat seluruh kartu bisa diklik */
    .product-button::before {
        content: "";
        position: absolute;
        inset: 0;
    }

    @media (hover: hover) {
        .product-card:hover {
            transform: translateY(-6px);
            border-color: #EBC98F;
            box-shadow: 0 14px 30px rgba(8,39,68,.1);
        }

        .product-card:hover .product-image img { transform: scale(1.05); }

        .product-card:hover .product-button {
            background: var(--c-gold);
            color: var(--c-navy);
        }

        .product-card:hover .product-button .cat-ic { transform: translateX(3px); }
    }

    /* =====================================
       TAMPILAN KOSONG
    ===================================== */

    .empty-catalog {
        grid-column: 1 / -1;
        padding: 64px 20px;
        border: 1px dashed #DCD5C6;
        border-radius: 18px;
        background: white;
        text-align: center;
    }

    .empty-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 76px;
        height: 76px;
        margin: 0 auto 18px;
        border-radius: 50%;
        background: #FFF3DC;
        color: #B87308;
    }

    .empty-catalog h3 {
        margin: 0 0 8px;
        color: var(--c-navy);
        font-size: 20px;
        font-weight: 800;
    }

    .empty-catalog p {
        max-width: 380px;
        margin: 0 auto 24px;
        color: var(--c-muted);
        line-height: 1.7;
    }

    .empty-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 13px 26px;
        border-radius: 999px;
        background: var(--c-gold);
        color: var(--c-navy);
        font-family: 'Manrope', 'Inter', sans-serif;
        font-size: 13px;
        font-weight: 800;
        transition: background-color .3s var(--c-ease), color .3s var(--c-ease);
    }

    @media (hover: hover) {
        .empty-btn:hover {
            background: var(--c-navy);
            color: white;
        }
    }

    .pagination-wrapper { margin-top: 38px; }

    /* =====================================
       RESPONSIVE
    ===================================== */

    @media (max-width: 1100px) {
        .product-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    }

    @media (max-width: 750px) {
        .catalog-page { padding: 24px 5% 70px; }

        .catalog-hero {
            padding: 30px 24px;
            border-radius: 18px;
        }

        .catalog-hero p { font-size: 14px; }

        .catalog-tools { flex-direction: column; }

        .catalog-search { min-width: 0; }

        .catalog-sort select { width: 100%; }

        .category-chips {
            margin-right: -5vw;
            padding-right: 5vw;
            -webkit-mask-image: linear-gradient(to right, #000 88%, transparent);
            mask-image: linear-gradient(to right, #000 88%, transparent);
        }

        .catalog-meta { margin: 14px 0 18px; }

        .product-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
        }

        .product-image { height: 165px; }

        .product-image img { padding: 10px; }

        .product-badge {
            top: 8px;
            left: 8px;
            padding: 4px 9px;
            font-size: 10px;
        }

        .product-info { padding: 12px; }

        .product-category { font-size: 10px; }

        .product-info h3 {
            margin: 6px 0;
            font-size: 13.5px;
        }

        .product-description { display: none; }

        .product-bottom {
            flex: 1;
            align-items: flex-end;
            margin-bottom: 10px;
        }

        .product-price { font-size: 14.5px; }

        .product-wa {
            width: 32px;
            height: 32px;
        }

        .product-button {
            padding: 10px;
            font-size: 12px;
        }
    }

    @media (max-width: 340px) {
        .product-grid { grid-template-columns: 1fr; }
    }

    /* Perangkat sentuh: tanpa efek hover yang menempel */
    @media (hover: none) {
        .product-card:hover {
            transform: none;
            border-color: var(--c-line);
            box-shadow: 0 2px 10px rgba(8,39,68,.04);
        }

        .product-card:hover .product-image img { transform: none; }
    }

    @media (prefers-reduced-motion: reduce) {
        .product-card,
        .product-image img,
        .chip { transition: none; }
    }
</style>

<div class="catalog-page">
    <div class="catalog-container">

        
        <section class="catalog-hero">

            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('home')); ?>">Beranda</a>
                <span aria-hidden="true">›</span>
                <span aria-current="page">Katalog</span>
            </nav>

            <h1>Explore Our <span>Collection.</span></h1>

            <p>
                Temukan furnitur dan dekorasi berkualitas untuk
                menciptakan ruang yang nyaman, elegan, dan alami.
                Crafting Comfort With Nature.
            </p>

        </section>

        
        <form action="<?php echo e(route('catalog.index')); ?>"
              method="GET"
              class="catalog-tools"
              role="search">

            <?php if(filled($categoryId ?? null)): ?>
                <input type="hidden" name="category" value="<?php echo e($categoryId); ?>">
            <?php endif; ?>

            <div class="catalog-search">

                <div class="search-field">

                    <?php echo $icon('search', 18); ?>


                    <input
                        type="search"
                        name="search"
                        placeholder="Cari nama produk..."
                        value="<?php echo e($searchTerm); ?>"
                        autocomplete="off"
                        aria-label="Cari produk"
                    >

                    <?php if($searchTerm !== ''): ?>
                        <a href="<?php echo e(route('catalog.index', $queryWithoutSearch)); ?>"
                           class="search-clear"
                           aria-label="Hapus pencarian">
                            <?php echo $icon('x', 16); ?>

                        </a>
                    <?php endif; ?>

                </div>

                <button type="submit" class="catalog-submit">
                    Cari
                </button>

            </div>

            
            <?php if(isset($sort)): ?>
                <div class="catalog-sort">
                    <select name="sort" onchange="this.form.submit()" aria-label="Urutkan produk">
                        <option value="newest" <?php echo e($sortValue === 'newest' ? 'selected' : ''); ?>>Terbaru</option>
                        <option value="price_asc" <?php echo e($sortValue === 'price_asc' ? 'selected' : ''); ?>>Harga Terendah</option>
                        <option value="price_desc" <?php echo e($sortValue === 'price_desc' ? 'selected' : ''); ?>>Harga Tertinggi</option>
                        <option value="name_asc" <?php echo e($sortValue === 'name_asc' ? 'selected' : ''); ?>>Nama A–Z</option>
                    </select>
                </div>
            <?php endif; ?>

        </form>

        
        <nav class="category-chips" aria-label="Kategori produk">

            <a href="<?php echo e($categoryUrl(null)); ?>"
               class="chip <?php echo e(filled($categoryId ?? null) ? '' : 'active'); ?>">
                Semua
            </a>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php $isActive = (string) ($categoryId ?? '') === (string) $category->id; ?>

                <a href="<?php echo e($categoryUrl($category->id)); ?>"
                   class="chip <?php echo e($isActive ? 'active' : ''); ?>"
                   <?php if($isActive): ?> aria-current="true" <?php endif; ?>>
                    <?php echo e($category->name); ?>

                </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </nav>

        
        <div class="catalog-meta">

            <p class="result-count">
                <?php if($products->total() > 0): ?>
                    Menampilkan
                    <strong><?php echo e($products->firstItem()); ?>–<?php echo e($products->lastItem()); ?></strong>
                    dari <strong><?php echo e($products->total()); ?></strong> produk
                <?php else: ?>
                    <strong>0</strong> produk ditemukan
                <?php endif; ?>
            </p>

            <?php if($hasFilters): ?>

                <div class="filter-tags">

                    <?php if($searchTerm !== ''): ?>
                        <span class="filter-tag">
                            “<?php echo e(\Illuminate\Support\Str::limit($searchTerm, 24)); ?>”
                            <a href="<?php echo e(route('catalog.index', $queryWithoutSearch)); ?>" aria-label="Hapus pencarian">
                                <?php echo $icon('x', 12); ?>

                            </a>
                        </span>
                    <?php endif; ?>

                    <?php if($activeCategory): ?>
                        <span class="filter-tag">
                            <?php echo e($activeCategory->name); ?>

                            <a href="<?php echo e($categoryUrl(null)); ?>" aria-label="Hapus kategori">
                                <?php echo $icon('x', 12); ?>

                            </a>
                        </span>
                    <?php endif; ?>

                    <a href="<?php echo e(route('catalog.index')); ?>" class="filter-reset">Hapus semua</a>

                </div>

            <?php endif; ?>

        </div>

        
        <div class="product-grid">

            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <?php
                    $pImage = $product->image
                        ? \Illuminate\Support\Facades\Storage::url($product->image)
                        : null;

                    $pHasPrice = !empty($product->price) && (float) $product->price > 0;
                ?>

                <article class="product-card">

                    <div class="product-image">

                        <?php if($product->is_featured): ?>
                            <span class="product-badge">Unggulan</span>
                        <?php endif; ?>

                        <?php if($pImage): ?>
                            <img
                                src="<?php echo e($pImage); ?>"
                                alt="<?php echo e($product->name); ?>"
                                width="480"
                                height="360"
                                loading="lazy"
                                decoding="async"
                            >
                        <?php else: ?>
                            <div class="product-no-image">
                                <?php echo $icon('image', 30); ?>

                                Foto segera hadir
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="product-info">

                        <div class="product-category">
                            <?php echo e($product->category?->name ?? 'Furnitur'); ?>

                        </div>

                        <h3><?php echo e($product->name); ?></h3>

                        <div class="product-description">
                            <?php echo e(\Illuminate\Support\Str::limit($product->description ?? 'Produk pilihan TERRAWOOD.', 75)); ?>

                        </div>

                        <div class="product-bottom">

                            <?php if($pHasPrice): ?>
                                <div class="product-price">
                                    Rp <?php echo e(number_format((float) $product->price, 0, ',', '.')); ?>

                                </div>
                            <?php else: ?>
                                <div class="product-price is-ask">
                                    Hubungi kami
                                </div>
                            <?php endif; ?>

                            <a href="<?php echo e($waProductUrl($product->name)); ?>"
                               class="product-wa"
                               target="_blank"
                               rel="noopener"
                               aria-label="Tanya <?php echo e($product->name); ?> via WhatsApp">
                                <?php echo $waIcon; ?>

                            </a>

                        </div>

                        <a href="<?php echo e(route('catalog.show', $product->slug)); ?>"
                           class="product-button">
                            Lihat Detail <?php echo $icon('arrow', 15); ?>

                        </a>

                    </div>

                </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="empty-catalog">

                    <div class="empty-icon"><?php echo $icon('search', 32); ?></div>

                    <h3>Produk Belum Ditemukan</h3>

                    <p>
                        Coba gunakan kata kunci atau kategori lainnya,
                        atau lihat semua koleksi kami.
                    </p>

                    <a href="<?php echo e(route('catalog.index')); ?>" class="empty-btn">
                        Lihat Semua Produk
                    </a>

                </div>

            <?php endif; ?>

        </div>

        
        <?php if($products->hasPages()): ?>
            <div class="pagination-wrapper">
                <?php echo e($products->appends(request()->except('page'))->links('vendor.pagination.terrawood')); ?>

            </div>
        <?php endif; ?>

    </div>
</div>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /* Geser chip kategori agar yang aktif terlihat di tengah (tanpa menggulir halaman) */

    const chips = document.querySelector('.category-chips');
    const activeChip = document.querySelector('.category-chips .chip.active');

    if (chips && activeChip) {

        const target = activeChip.offsetLeft - (chips.clientWidth - activeChip.offsetWidth) / 2;

        chips.scrollLeft = Math.max(0, target);

    }

});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\terrawood\resources\views/catalog/index.blade.php ENDPATH**/ ?>