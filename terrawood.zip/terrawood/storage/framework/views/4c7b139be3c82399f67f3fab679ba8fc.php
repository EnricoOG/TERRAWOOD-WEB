

<?php $__env->startSection('title', 'Beranda | TERRAWOOD'); ?>

<?php $__env->startPush('styles'); ?>
<style>
:root {
    --tw-navy: #082744;
    --tw-dark: #061D33;
    --tw-gold: #F5A623;
    --tw-orange: #FFA43A;
    --tw-blue: #1677D2;
    --tw-blue-hover: #0D5EAD;
    --tw-ivory: #F7F5EF;
    --tw-text: #293747;
    --tw-muted: #687482;
    --tw-ease: cubic-bezier(.22, .61, .36, 1);
}

html {
    scroll-behavior: smooth;
    scroll-padding-top: 80px;
}

.home-page,
.home-page *,
.home-page *::before,
.home-page *::after { box-sizing: border-box; }

.home-page {
    overflow: hidden;
    background: var(--tw-ivory);
    font-family: 'Inter', sans-serif;
    color: var(--tw-text);
}

.home-page h1,
.home-page h2,
.home-page h3,
.home-page h4 {
    font-family: 'Manrope', sans-serif;
}

.home-page a { text-decoration: none; }

.home-page a:focus-visible,
.home-page button:focus-visible {
    outline: 2px solid var(--tw-orange);
    outline-offset: 3px;
}

.section-container {
    width: 86%;
    max-width: 1400px;
    margin: auto;
}

.section-label {
    color: #C47A1B;
    font-size: 13px;
    font-weight: 800;
    letter-spacing: 3px;
    text-transform: uppercase;
    margin-bottom: 14px;
}

.section-title {
    color: var(--tw-navy);
    font-family: 'Manrope', sans-serif;
    font-size: clamp(30px, 3.2vw, 42px);
    line-height: 1.25;
    font-weight: 800;
}

.section-description {
    color: var(--tw-muted);
    font-size: 15px;
    line-height: 1.9;
    margin-top: 14px;
}

.section-heading { margin-bottom: 38px; }
.section-heading.center { text-align: center; }

/* =====================================
   ANIMASI MUNCUL SAAT SCROLL
   (kelas .reveal hanya ditambahkan oleh JS)
===================================== */

.reveal {
    opacity: 0;
    transform: translateY(22px);
    transition: opacity .6s ease, transform .6s ease;
}

.reveal.in {
    opacity: 1;
    transform: none;
}

/* =====================================
   HERO SLIDER
===================================== */

.hero {
    position: relative;
    min-height: 610px;
    background: var(--tw-navy);
    overflow: hidden;
}

.hero-track {
    display: flex;
    width: 100%;
    min-height: 610px;
    transition: transform .75s cubic-bezier(.65, 0, .35, 1);
    will-change: transform;
}

.hero-slide {
    display: grid;
    grid-template-columns: 1fr 1fr;
    flex: 0 0 100%;
    width: 100%;
    min-height: 610px;
}

/* BAGIAN TEKS - KANAN / GOLD */

.hero-left {
    grid-column: 2;
    grid-row: 1;
    background:
        radial-gradient(circle at 15% 15%, rgba(255,255,255,.22), transparent 35%),
        linear-gradient(145deg, #F5A623, #FFA43A);
    position: relative;
    min-height: 610px;
    overflow: hidden;
    display: flex;
    align-items: center;
    padding: 125px 8% 90px 12%;
}

.hero-left::before {
    content: "";
    position: absolute;
    width: 360px;
    height: 360px;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 50%;
    left: -145px;
    bottom: -190px;
    pointer-events: none;
}

.hero-left::after {
    content: "";
    position: absolute;
    width: 230px;
    height: 230px;
    border: 1px solid rgba(245,166,35,.24);
    border-radius: 50%;
    right: -145px;
    top: 80px;
    pointer-events: none;
}

.hero-content {
    position: relative;
    z-index: 2;
    max-width: 550px;
}

.hero-label {
    font-size: 11px;
    letter-spacing: 3.5px;
    color: var(--tw-navy);
    margin-bottom: 18px;
    font-weight: 800;
    text-transform: uppercase;
}

.hero-content h1 {
    font-family: 'Manrope', sans-serif;
    font-size: clamp(38px, 4.2vw, 62px);
    line-height: 1.12;
    font-weight: 800;
    color: var(--tw-navy);
    margin-bottom: 23px;
}

.hero-content h1 span { color: white; }

.hero-description {
    color: rgba(8,39,68,.86);
    font-size: 14px;
    line-height: 1.95;
    max-width: 440px;
    margin-bottom: 29px;
}

.hero-button {
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 14px;
    padding: 9px 9px 9px 28px;
    border: 0;
    border-radius: 999px;
    background: var(--tw-navy);
    color: white;
    font-family: 'Manrope', 'Inter', sans-serif;
    font-size: 13px;
    font-weight: 800;
    letter-spacing: .3px;
    line-height: 1;
    cursor: pointer;
    box-shadow: 0 10px 24px rgba(8,39,68,.28);
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
    transition:
        background-color .35s var(--tw-ease),
        color .35s var(--tw-ease),
        transform .35s var(--tw-ease),
        box-shadow .35s var(--tw-ease);
}

.btn-arrow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: rgba(255,255,255,.14);
    font-size: 15px;
    line-height: 1;
    transition:
        background-color .35s var(--tw-ease),
        color .35s var(--tw-ease),
        transform .35s var(--tw-ease);
}

.hero-button:focus-visible {
    outline-color: var(--tw-navy);
    outline-offset: 4px;
}

@media (hover: hover) {
    .hero-button:hover {
        background: white;
        color: var(--tw-navy);
        transform: translateY(-2px);
        box-shadow: 0 14px 30px rgba(8,39,68,.3);
    }

    .hero-button:hover .btn-arrow {
        background: var(--tw-navy);
        color: white;
        transform: translateX(3px);
    }
}

.hero-button:active {
    transform: translateY(0) scale(.97);
    transition-duration: .12s;
}

.hero-kicker {
    display: flex;
    align-items: center;
    gap: 10px;
    color: rgba(8,39,68,.72);
    font-size: 11px;
    letter-spacing: 1.5px;
    margin-top: 35px;
}

.hero-kicker::before {
    content: "";
    width: 35px;
    height: 1px;
    background: var(--tw-gold);
}

/* BAGIAN FOTO - KIRI / BIRU TUA */

.hero-right {
    grid-column: 1;
    grid-row: 1;
    position: relative;
    min-height: 610px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 100px 7% 75px;
    overflow: hidden;
    background: var(--tw-navy);
}

.hero-right::before {
    content: "";
    position: absolute;
    inset: 0;
    background:
        radial-gradient(circle at 80% 18%, rgba(255,255,255,.09), transparent 38%),
        linear-gradient(135deg, #082744, #061D33);
}

.hero-product-frame {
    position: relative;
    z-index: 1;
    width: 100%;
    height: 455px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 12px;
}

.hero-product-image {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: contain;
    object-position: center;
}

.hero-image-caption {
    position: absolute;
    z-index: 2;
    left: 8%;
    bottom: 34px;
    color: rgba(255,255,255,.9);
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 2px;
    text-transform: uppercase;
}

.hero-controls {
    position: absolute;
    right: 5%;
    bottom: 22px;
    display: flex;
    align-items: center;
    gap: 13px;
    z-index: 5;
    color: white;
    font-size: 14px;
}

.hero-counter { min-width: 55px; }
.hero-counter strong { font-size: 17px; font-weight: 800; }

.hero-controls button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 42px;
    height: 42px;
    padding: 0;
    border: 1px solid rgba(255,255,255,.45);
    border-radius: 50%;
    background: rgba(8,39,68,.35);
    -webkit-backdrop-filter: blur(6px);
    backdrop-filter: blur(6px);
    color: white;
    cursor: pointer;
    font-size: 17px;
    line-height: 1;
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
    transition:
        background-color .3s var(--tw-ease),
        color .3s var(--tw-ease),
        border-color .3s var(--tw-ease),
        transform .3s var(--tw-ease);
}

@media (hover: hover) {
    .hero-controls button:hover {
        background: var(--tw-gold);
        color: var(--tw-navy);
        border-color: var(--tw-gold);
        transform: scale(1.08);
    }
}

.hero-controls button:active {
    transform: scale(.94);
    transition-duration: .12s;
}

/* INDIKATOR TITIK SLIDER */

.hero-controls .hero-dots {
    display: flex;
    align-items: center;
    gap: 8px;
}

.hero-controls .hero-dots button {
    width: 9px;
    height: 9px;
    min-width: 9px;
    padding: 0;
    border: 0;
    border-radius: 6px;
    background: rgba(255,255,255,.45);
    -webkit-backdrop-filter: none;
    backdrop-filter: none;
    font-size: 0;
    transition: width .3s ease, background .3s ease;
}

.hero-controls .hero-dots button:hover {
    background: rgba(255,255,255,.8);
    transform: none;
}

.hero-controls .hero-dots button.active {
    width: 24px;
    background: var(--tw-gold);
}

/* ANIMASI MASUK SLIDE AKTIF */

.hero-slide.is-active .hero-content > * {
    animation: heroTextIn .8s var(--tw-ease) backwards;
}

.hero-slide.is-active .hero-content > *:nth-child(1) { animation-delay: .12s; }
.hero-slide.is-active .hero-content > *:nth-child(2) { animation-delay: .22s; }
.hero-slide.is-active .hero-content > *:nth-child(3) { animation-delay: .32s; }
.hero-slide.is-active .hero-content > *:nth-child(4) { animation-delay: .42s; }
.hero-slide.is-active .hero-content > *:nth-child(5) { animation-delay: .52s; }

.hero-slide.is-active .hero-product-image {
    animation: heroImageIn 1s var(--tw-ease) .1s backwards;
}

@keyframes heroTextIn {
    from { opacity: 0; transform: translateY(18px); }
    to   { opacity: 1; transform: none; }
}

@keyframes heroImageIn {
    from { opacity: 0; transform: translateY(12px) scale(.95); }
    to   { opacity: 1; transform: none; }
}

/* =====================================
   BENEFIT STRIP
===================================== */

.benefit-strip {
    background: #FFF9F0;
    padding: 27px 7%;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    border-bottom: 1px solid #F0E6D8;
}

.benefit-item {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    padding: 8px 15px;
    border-right: 1px solid #E9B66F;
}

.benefit-item:last-child { border-right: none; }

.benefit-icon {
    width: 44px;
    height: 44px;
    min-width: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #D58A22;
    background: #FFF0D8;
    border-radius: 12px;
}

.benefit-icon svg {
    width: 25px;
    height: 25px;
    stroke: currentColor;
    fill: none;
    stroke-width: 1.8;
    stroke-linecap: round;
    stroke-linejoin: round;
}

.benefit-item strong {
    color: var(--tw-navy);
    display: block;
    font-size: 14px;
    font-weight: 800;
}

.benefit-item span {
    display: block;
    color: var(--tw-muted);
    font-size: 12px;
    margin-top: 5px;
}

/* =====================================
   PRODUCTS
===================================== */

.products-section {
    padding: 85px 7%;
    background: var(--tw-ivory);
}

.products-layout {
    display: grid;
    grid-template-columns: 270px 1fr;
    gap: 38px;
    align-items: center;
}

.products-intro .section-title { font-size: 32px; }

.products-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 17px;
}

.product-card {
    background: white;
    border-radius: 11px;
    overflow: hidden;
    box-shadow: 0 3px 12px rgba(8,39,68,.07);
    transition: transform .3s ease, box-shadow .3s ease;
}

.product-card:hover {
    transform: translateY(-7px);
    box-shadow: 0 12px 25px rgba(8,39,68,.12);
}

.product-image {
    height: 175px;
    background: #ECE9E1;
    overflow: hidden;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    padding: 7px;
    transition: transform .4s ease;
}

.product-card:hover .product-image img {
    transform: scale(1.035);
}

.product-info { padding: 16px; }

.product-category {
    color: #C47A1B;
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
}

.product-name {
    color: var(--tw-navy);
    font-size: 14px;
    font-weight: 800;
    margin: 9px 0;
    line-height: 1.5;
}

.product-price {
    color: var(--tw-text);
    font-size: 13px;
    font-weight: 800;
}

.product-card { position: relative; }

.product-detail {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 13px;
    padding-bottom: 3px;
    color: #B66D14;
    font-size: 12px;
    font-weight: 800;
    background: linear-gradient(currentColor, currentColor) no-repeat 0 100% / 0 1.5px;
    transition:
        color .3s var(--tw-ease),
        background-size .35s var(--tw-ease);
}

/* Membuat seluruh kartu produk bisa diklik */
.product-detail::before {
    content: "";
    position: absolute;
    inset: 0;
}

.product-detail span {
    display: inline-block;
    transition: transform .3s var(--tw-ease);
}

@media (hover: hover) {
    .product-card:hover .product-detail {
        color: var(--tw-navy);
        background-size: 100% 1.5px;
    }

    .product-card:hover .product-detail span {
        transform: translateX(4px);
    }
}

.products-link {
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 14px;
    margin-top: 23px;
    padding: 8px 8px 8px 26px;
    border-radius: 999px;
    background: var(--tw-orange);
    color: var(--tw-navy);
    font-family: 'Manrope', 'Inter', sans-serif;
    font-size: 13px;
    font-weight: 800;
    letter-spacing: .3px;
    line-height: 1;
    box-shadow: 0 8px 20px rgba(255,164,58,.32);
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
    transition:
        background-color .35s var(--tw-ease),
        color .35s var(--tw-ease),
        transform .35s var(--tw-ease),
        box-shadow .35s var(--tw-ease);
}

.products-link .btn-arrow {
    width: 34px;
    height: 34px;
    background: rgba(8,39,68,.12);
}

.products-link:focus-visible {
    outline-color: var(--tw-navy);
    outline-offset: 4px;
}

@media (hover: hover) {
    .products-link:hover {
        background: var(--tw-navy);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 12px 26px rgba(8,39,68,.28);
    }

    .products-link:hover .btn-arrow {
        background: var(--tw-orange);
        color: var(--tw-navy);
        transform: translateX(3px);
    }
}

.products-link:active {
    transform: translateY(0) scale(.97);
    transition-duration: .12s;
}

.product-empty {
    grid-column: 1 / -1;
    text-align: center;
    padding: 40px;
    background: white;
    border-radius: 10px;
    color: var(--tw-muted);
    font-size: 14px;
}

/* =====================================
   ABOUT
===================================== */

.about-section {
    display: grid;
    grid-template-columns: 42% 58%;
    min-height: 350px;
    background: var(--tw-navy);
}

.about-image {
    min-height: 350px;
    overflow: hidden;
    background: #EDE7DC;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 25px;
}

.about-image img {
    width: 100%;
    height: 100%;
    min-height: 300px;
    object-fit: contain;
}

.about-content {
    padding: 55px 8%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    color: white;
}

.about-content .section-title {
    color: white;
    font-size: 34px;
}

.about-content p {
    color: rgba(255,255,255,.85);
    font-size: 14px;
    line-height: 1.9;
    margin-top: 15px;
    max-width: 570px;
}

.about-stats {
    display: flex;
    gap: 40px;
    margin-top: 30px;
    flex-wrap: wrap;
}

.about-stat strong {
    display: block;
    color: var(--tw-orange);
    font-size: 31px;
    font-family: 'Manrope', sans-serif;
    font-weight: 800;
}

.about-stat span {
    color: white;
    font-size: 12px;
}

/* =====================================
   PARTNERS
===================================== */

.partners-section {
    padding: 75px 7%;
    background: white;
}

.partners-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
}

.partner-card {
    min-height: 130px;
    padding: 22px;
    border: 1px solid #EEE7DB;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
    transition: border-color .3s ease, transform .3s ease;
}

.partner-card:hover {
    border-color: var(--tw-gold);
    transform: translateY(-5px);
}

.partner-card img {
    max-width: 140px;
    max-height: 60px;
    object-fit: contain;
    margin-bottom: 12px;
}

.partner-card strong {
    color: var(--tw-navy);
    font-size: 14px;
}

.home-empty {
    grid-column: 1 / -1;
    background: rgba(255,255,255,.8);
    border: 1px dashed #D9CBB8;
    border-radius: 10px;
    text-align: center;
    padding: 35px 20px;
    color: var(--tw-muted);
    font-size: 14px;
}

/* =====================================
   TESTIMONIALS
===================================== */

.testimonials-section {
    padding: 62px 7%;
    background: var(--tw-navy);
}

.testimonials-section .section-title { color: white; }

.testimonials-section .section-description {
    color: rgba(255,255,255,.8);
}

.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 18px;
    max-width: 1120px;
    margin: 0 auto;
}

.testimonial-card {
    background: #FFF9F0;
    border-radius: 11px;
    padding: 20px;
    min-width: 0;
}

.testimonial-stars {
    color: #F5A623;
    letter-spacing: 2px;
    font-size: 15px;
    margin-bottom: 10px;
}

.testimonial-text {
    color: var(--tw-text);
    font-size: 13px;
    line-height: 1.65;
    font-style: italic;
    margin: 0;
}

.testimonial-person {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 16px;
}

.testimonial-person img {
    width: 42px;
    height: 42px;
    min-width: 42px;
    object-fit: cover;
    border-radius: 50%;
    display: block;
}

.testimonial-avatar {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--tw-navy);
    color: var(--tw-gold);
    font-family: 'Manrope', sans-serif;
    font-size: 14px;
    font-weight: 800;
    flex-shrink: 0;
}

.testimonial-person strong {
    display: block;
    color: var(--tw-navy);
    font-size: 13px;
    font-weight: 800;
}

.testimonial-person span {
    color: var(--tw-muted);
    font-size: 11px;
    display: block;
    margin-top: 4px;
}

/* =====================================
   TEXT LINK & JUDUL DENGAN TAUTAN
===================================== */

.section-heading.split {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 20px;
}

.text-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 3px;
    color: #B66D14;
    font-size: 13px;
    font-weight: 800;
    white-space: nowrap;
    background: linear-gradient(currentColor, currentColor) no-repeat 0 100% / 0 1.5px;
    -webkit-tap-highlight-color: transparent;
    transition: color .3s var(--tw-ease), background-size .35s var(--tw-ease);
}

.text-link span {
    display: inline-block;
    transition: transform .3s var(--tw-ease);
}

.text-link:active { background-size: 100% 1.5px; }

@media (hover: hover) {
    .text-link:hover {
        color: var(--tw-navy);
        background-size: 100% 1.5px;
    }

    .text-link:hover span { transform: translateX(4px); }
}

/* =====================================
   KATEGORI
===================================== */

.categories-section {
    padding: 85px 7% 70px;
    background: white;
}

.categories-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 18px;
}

.category-tile {
    position: relative;
    display: block;
    aspect-ratio: 4 / 3;
    border-radius: 16px;
    overflow: hidden;
    background: linear-gradient(135deg, #0F3558, #061D33);
    box-shadow: 0 6px 18px rgba(8,39,68,.12);
    -webkit-tap-highlight-color: transparent;
    transition: transform .35s var(--tw-ease), box-shadow .35s var(--tw-ease);
}

.category-tile img {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: contain;
    padding: 20px 24px 76px;
    transition: transform .5s var(--tw-ease);
}

.category-label {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 38px 20px 18px;
    background: linear-gradient(to top, rgba(6,29,51,.95) 35%, rgba(6,29,51,0));
    color: white;
}

.category-label strong {
    display: block;
    font-family: 'Manrope', sans-serif;
    font-size: 17px;
    font-weight: 800;
    line-height: 1.25;
}

.category-label small {
    display: block;
    margin-top: 3px;
    color: var(--tw-orange);
    font-size: 11.5px;
    font-weight: 700;
    letter-spacing: .4px;
}

.category-tile:active {
    transform: scale(.985);
    transition-duration: .12s;
}

@media (hover: hover) {
    .category-tile:hover {
        transform: translateY(-5px);
        box-shadow: 0 16px 32px rgba(8,39,68,.2);
    }

    .category-tile:hover img { transform: scale(1.05); }

    .category-tile:hover .btn-arrow {
        background: var(--tw-gold);
        color: var(--tw-navy);
        transform: translateX(3px);
    }
}

/* =====================================
   PERNYATAAN (FILOSOFI)
===================================== */

.statement-section {
    position: relative;
    overflow: hidden;
    padding: 105px 7%;
    background:
        radial-gradient(circle at 80% 0%, rgba(245,166,35,.16), transparent 45%),
        var(--tw-dark);
    text-align: center;
}

.statement-inner {
    position: relative;
    z-index: 1;
    max-width: 900px;
    margin: 0 auto;
}

.statement-section .section-label { color: var(--tw-gold); }

.home-page .statement-quote {
    font-family: var(--font-editorial, 'Playfair Display', serif);
    font-size: clamp(30px, 4.4vw, 56px);
    line-height: 1.2;
    font-weight: 500;
    letter-spacing: -.3px;
    color: white;
}

.statement-quote em {
    color: var(--tw-gold);
    font-style: italic;
}

.statement-points {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 28px;
    margin-top: 56px;
    padding-top: 34px;
    border-top: 1px solid rgba(255,255,255,.14);
    text-align: left;
}

.statement-points strong {
    display: block;
    margin-bottom: 8px;
    color: white;
    font-family: 'Manrope', sans-serif;
    font-size: 15px;
    font-weight: 800;
}

.statement-points strong::before {
    content: "";
    display: block;
    width: 28px;
    height: 2px;
    margin-bottom: 14px;
    background: var(--tw-gold);
}

.statement-points span {
    color: rgba(255,255,255,.72);
    font-size: 13.5px;
    line-height: 1.75;
}

/* =====================================
   LAYANAN
===================================== */

.services-section {
    padding: 85px 7%;
    background: white;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
}

.service-card {
    position: relative;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    padding: 28px 24px 24px;
    background: #FFF9F0;
    border: 1px solid #F0E6D8;
    border-radius: 16px;
    -webkit-tap-highlight-color: transparent;
    transition: transform .35s var(--tw-ease), box-shadow .35s var(--tw-ease), border-color .35s var(--tw-ease);
}

.service-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, var(--tw-gold), var(--tw-orange));
    transform: scaleX(0);
    transform-origin: left;
    transition: transform .45s var(--tw-ease);
}

.service-index {
    position: absolute;
    top: 16px;
    right: 20px;
    font-family: 'Manrope', sans-serif;
    font-size: 34px;
    font-weight: 800;
    line-height: 1;
    color: rgba(8,39,68,.07);
}

.service-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 52px;
    height: 52px;
    margin-bottom: 20px;
    border-radius: 14px;
    background: #FFF0D8;
    color: #C47A1B;
}

.service-icon svg {
    width: 26px;
    height: 26px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.8;
    stroke-linecap: round;
    stroke-linejoin: round;
}

.service-media {
    display: block;
    height: 140px;
    margin-bottom: 18px;
    overflow: hidden;
    border-radius: 10px;
    background: #ECE9E1;
}

.service-media img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.service-card h3 {
    margin-bottom: 10px;
    color: var(--tw-navy);
    font-size: 17px;
    font-weight: 800;
    line-height: 1.35;
}

.service-card p {
    flex: 1;
    color: var(--tw-muted);
    font-size: 13.5px;
    line-height: 1.75;
}

.service-more {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 20px;
    color: #B66D14;
    font-size: 12.5px;
    font-weight: 800;
}

.service-more span {
    display: inline-block;
    transition: transform .3s var(--tw-ease);
}

.service-card:active {
    transform: scale(.985);
    transition-duration: .12s;
}

@media (hover: hover) {
    .service-card:hover {
        transform: translateY(-5px);
        border-color: #EBC98F;
        box-shadow: 0 14px 30px rgba(8,39,68,.1);
    }

    .service-card:hover::before { transform: scaleX(1); }

    .service-card:hover .service-more span { transform: translateX(4px); }
}

/* =====================================
   PROYEK PILIHAN (PORTOFOLIO)
===================================== */

.portfolio-section {
    padding: 85px 7%;
    background: var(--tw-ivory);
}

.portfolio-grid {
    display: grid;
    grid-template-columns: 1.4fr 1fr 1fr;
    grid-template-rows: 270px 270px;
    gap: 16px;
}

.portfolio-item {
    position: relative;
    display: block;
    overflow: hidden;
    border-radius: 16px;
    background: #ECE9E1;
    -webkit-tap-highlight-color: transparent;
}

.portfolio-item:nth-child(1) { grid-row: 1 / 3; }

.portfolio-item:nth-child(4) { grid-column: 2 / 4; }

.portfolio-item img {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform .6s var(--tw-ease);
}

.portfolio-item img.is-fallback {
    object-fit: contain;
    padding: 28px;
}

.portfolio-caption {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 46px 22px 20px;
    background: linear-gradient(to top, rgba(6,29,51,.9), rgba(6,29,51,0));
    color: white;
}

.portfolio-caption strong {
    display: block;
    font-family: 'Manrope', sans-serif;
    font-size: 16px;
    font-weight: 800;
    line-height: 1.3;
}

.portfolio-caption small {
    display: block;
    margin-top: 4px;
    color: var(--tw-orange);
    font-size: 11.5px;
    font-weight: 700;
    letter-spacing: .4px;
}

.portfolio-item:active img { transform: scale(1.03); }

@media (hover: hover) {
    .portfolio-item:hover img { transform: scale(1.06); }
}

/* =====================================
   CARA PEMESANAN
===================================== */

.steps-section {
    padding: 85px 7%;
    background: #FFF9F0;
}

.steps-grid {
    position: relative;
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 24px;
}

.steps-grid::before {
    content: "";
    position: absolute;
    top: 34px;
    left: 12.5%;
    right: 12.5%;
    height: 2px;
    background: repeating-linear-gradient(90deg, #E4B574 0 8px, transparent 8px 16px);
}

.step-item {
    position: relative;
    padding: 0 8px;
    text-align: center;
}

.step-badge {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 68px;
    height: 68px;
    margin: 0 auto 20px;
    border: 2px solid #F0C98C;
    border-radius: 50%;
    background: white;
    color: #C47A1B;
    box-shadow: 0 6px 16px rgba(196,122,27,.15);
}

.step-badge svg {
    width: 28px;
    height: 28px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.8;
    stroke-linecap: round;
    stroke-linejoin: round;
}

.step-number {
    position: absolute;
    top: -6px;
    right: -6px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    background: var(--tw-navy);
    color: white;
    font-family: 'Manrope', sans-serif;
    font-size: 12px;
    font-weight: 800;
}

.step-item h3 {
    margin-bottom: 8px;
    color: var(--tw-navy);
    font-size: 16px;
    font-weight: 800;
}

.step-item p {
    color: var(--tw-muted);
    font-size: 13.5px;
    line-height: 1.75;
}

.steps-cta {
    margin-top: 44px;
    text-align: center;
}

/* =====================================
   ARTIKEL TERBARU
===================================== */

.articles-section {
    padding: 85px 7% 70px;
    background: var(--tw-ivory);
}

.articles-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 20px;
}

.article-card {
    display: flex;
    flex-direction: column;
    overflow: hidden;
    border-radius: 16px;
    background: white;
    box-shadow: 0 3px 12px rgba(8,39,68,.07);
    -webkit-tap-highlight-color: transparent;
    transition: transform .35s var(--tw-ease), box-shadow .35s var(--tw-ease);
}

.article-thumb {
    display: block;
    aspect-ratio: 16 / 10;
    overflow: hidden;
    background: #ECE9E1;
}

.article-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform .5s var(--tw-ease);
}

.article-thumb img.is-fallback {
    object-fit: contain;
    padding: 14px;
}

.article-body {
    display: flex;
    flex: 1;
    flex-direction: column;
    padding: 22px;
}

.article-date {
    margin-bottom: 10px;
    color: #B66D14;
    font-size: 11.5px;
    font-weight: 800;
    letter-spacing: .8px;
    text-transform: uppercase;
}

.article-card h3 {
    display: -webkit-box;
    margin-bottom: 10px;
    overflow: hidden;
    color: var(--tw-navy);
    font-size: 17px;
    font-weight: 800;
    line-height: 1.4;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}

.article-card p {
    display: -webkit-box;
    flex: 1;
    overflow: hidden;
    color: var(--tw-muted);
    font-size: 13.5px;
    line-height: 1.75;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
}

.article-more {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 16px;
    color: #B66D14;
    font-size: 12.5px;
    font-weight: 800;
}

.article-more span {
    display: inline-block;
    transition: transform .3s var(--tw-ease);
}

.article-card:active {
    transform: scale(.985);
    transition-duration: .12s;
}

@media (hover: hover) {
    .article-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 14px 28px rgba(8,39,68,.12);
    }

    .article-card:hover .article-thumb img { transform: scale(1.05); }

    .article-card:hover .article-more span { transform: translateX(4px); }
}

/* =====================================
   BANNER AJAKAN (CTA)
===================================== */

.cta-section {
    padding: 20px 7% 90px;
    background: var(--tw-ivory);
}

.cta-box {
    position: relative;
    display: grid;
    grid-template-columns: 1.4fr 1fr;
    align-items: center;
    gap: 30px;
    overflow: hidden;
    padding: 56px;
    border-radius: 24px;
    background:
        radial-gradient(circle at 15% 15%, rgba(255,255,255,.22), transparent 35%),
        linear-gradient(145deg, #F5A623, #FFA43A);
}

.cta-box::before {
    content: "";
    position: absolute;
    right: -90px;
    bottom: -140px;
    width: 340px;
    height: 340px;
    border: 1px solid rgba(255,255,255,.25);
    border-radius: 50%;
    pointer-events: none;
}

.cta-box > div { position: relative; z-index: 1; }

.cta-label {
    margin-bottom: 14px;
    color: var(--tw-navy);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 3.5px;
    text-transform: uppercase;
}

.cta-box h2 {
    margin-bottom: 12px;
    color: var(--tw-navy);
    font-size: clamp(26px, 3vw, 38px);
    font-weight: 800;
    line-height: 1.2;
}

.cta-box p {
    max-width: 520px;
    color: rgba(8,39,68,.82);
    font-size: 15px;
    line-height: 1.8;
}

.cta-actions {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
    justify-self: end;
}

.cta-secondary {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 54px;
    padding: 0 28px;
    border: 2px solid var(--tw-navy);
    border-radius: 999px;
    color: var(--tw-navy);
    font-family: 'Manrope', 'Inter', sans-serif;
    font-size: 13px;
    font-weight: 800;
    -webkit-tap-highlight-color: transparent;
    transition: background-color .35s var(--tw-ease), color .35s var(--tw-ease), transform .35s var(--tw-ease);
}

.cta-secondary:active {
    transform: scale(.97);
    transition-duration: .12s;
}

@media (hover: hover) {
    .cta-secondary:hover {
        background: var(--tw-navy);
        color: white;
        transform: translateY(-2px);
    }
}

/* =====================================
   SECTION BARU: TABLET & HP
===================================== */

@media(max-width: 1100px) {
    .services-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }

    .portfolio-grid {
        grid-template-columns: 1fr 1fr;
        grid-template-rows: 300px 220px 220px;
    }

    .portfolio-item:nth-child(1) { grid-column: 1 / 3; grid-row: 1; }
    .portfolio-item:nth-child(2) { grid-column: 1; grid-row: 2; }
    .portfolio-item:nth-child(3) { grid-column: 2; grid-row: 2; }
    .portfolio-item:nth-child(4) { grid-column: 1 / 3; grid-row: 3; }

    .steps-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 36px 24px;
    }

    .steps-grid::before { display: none; }

    .cta-box {
        grid-template-columns: 1fr;
        padding: 44px 36px;
    }

    .cta-actions {
        flex-direction: row;
        flex-wrap: wrap;
        align-items: center;
        justify-self: start;
    }
}

@media(max-width: 760px) {
    .categories-section { padding: 56px 6% 48px; }

    .statement-section { padding: 72px 7%; }

    .services-section,
    .portfolio-section,
    .steps-section { padding: 56px 6%; }

    .articles-section { padding: 56px 6% 48px; }

    .cta-section { padding: 12px 6% 60px; }

    .section-heading.split {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }

    .categories-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
    }

    .category-tile img { padding: 12px 14px 60px; }

    .category-label { padding: 30px 12px 12px; }

    .category-label strong { font-size: 14px; }

    .category-label small { font-size: 10.5px; }

    .category-label .btn-arrow {
        width: 28px;
        height: 28px;
        font-size: 12px;
    }

    .statement-points {
        grid-template-columns: 1fr;
        gap: 22px;
        margin-top: 40px;
    }

    .services-grid {
        grid-template-columns: 1fr;
        gap: 12px;
    }

    .service-card { padding: 22px 20px; }

    .portfolio-grid {
        gap: 10px;
        grid-template-rows: 220px 150px 170px;
    }

    .portfolio-caption { padding: 34px 14px 14px; }

    .portfolio-caption strong { font-size: 13.5px; }

    .steps-grid {
        grid-template-columns: 1fr;
        gap: 26px;
    }

    .step-item {
        display: grid;
        grid-template-columns: 68px 1fr;
        gap: 16px;
        align-items: start;
        padding: 0;
        text-align: left;
    }

    .step-badge { margin: 0; }

    .steps-cta { margin-top: 36px; }

    .articles-grid {
        grid-template-columns: 1fr;
        gap: 14px;
    }

    .article-card {
        display: grid;
        grid-template-columns: 116px 1fr;
    }

    .article-thumb {
        aspect-ratio: auto;
        height: 100%;
        min-height: 128px;
    }

    .article-body { padding: 14px 16px; }

    .article-card h3 {
        margin-bottom: 4px;
        font-size: 14.5px;
    }

    .article-card p { display: none; }

    .article-more { margin-top: 8px; }

    .cta-box {
        padding: 34px 24px;
        border-radius: 20px;
    }

    .cta-box p { font-size: 14px; }

    .cta-actions {
        flex-direction: column;
        align-items: stretch;
        width: 100%;
        max-width: 340px;
    }
}

@media(max-width: 340px) {
    .categories-grid { grid-template-columns: 1fr; }
}

/* Perangkat sentuh: tanpa efek hover yang menempel */

@media (hover: none) {
    .category-tile:hover,
    .service-card:hover,
    .article-card:hover {
        transform: none;
    }

    .category-tile:hover img,
    .portfolio-item:hover img,
    .article-card:hover .article-thumb img { transform: none; }
}

/* =====================================
   RESPONSIVE TABLET
===================================== */

@media(max-width: 1100px) {
    .products-layout {
        grid-template-columns: 220px 1fr;
    }

    .products-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .product-image { height: 190px; }

}

/* =====================================
   RESPONSIVE MOBILE
===================================== */

@media(max-width: 760px) {

    /* ----- Tipografi umum ----- */

    .section-title { font-size: clamp(26px, 7vw, 32px); }

    .section-label {
        font-size: 12px;
        letter-spacing: 2.5px;
        margin-bottom: 10px;
    }

    .section-description {
        font-size: 14.5px;
        line-height: 1.8;
    }

    .section-heading { margin-bottom: 26px; }


    /* ----- Hero ----- */

    .hero,
    .hero-track { min-height: auto; }

    .hero-slide {
        grid-template-columns: 1fr;
        min-height: auto;
    }

    .hero-left,
    .hero-right {
        grid-column: auto;
        grid-row: auto;
    }

    .hero-left {
        min-height: 0;
        padding: 104px 7% 44px;
    }

    .hero-content { max-width: none; }

    .hero-label {
        font-size: 10.5px;
        letter-spacing: 3px;
        margin-bottom: 14px;
    }

    .hero-content h1 {
        font-size: clamp(34px, 10.5vw, 44px);
        margin-bottom: 16px;
    }

    .hero-description {
        font-size: 14.5px;
        line-height: 1.8;
        max-width: none;
        margin-bottom: 24px;
    }

    .hero-button {
        width: 100%;
        max-width: 340px;
        justify-content: space-between;
    }

    .hero-kicker {
        margin-top: 24px;
        font-size: 10px;
    }

    .hero-right {
        min-height: 0;
        padding: 26px 6% 78px;
    }

    .hero-product-frame {
        height: 250px;
        padding: 4px;
    }

    .hero-image-caption { display: none; }

    .hero-controls {
        left: 50%;
        right: auto;
        bottom: 22px;
        gap: 14px;
        transform: translateX(-50%);
    }

    .hero-counter { display: none; }


    /* ----- Benefit ----- */

    .benefit-strip {
        grid-template-columns: repeat(2, 1fr);
        gap: 0;
        padding: 6px 5%;
    }

    .benefit-item {
        justify-content: flex-start;
        gap: 12px;
        padding: 16px 6px;
        border-right: none;
        border-bottom: 1px solid #F0DDC2;
    }

    .benefit-item:nth-last-child(-n+2) { border-bottom: none; }

    .benefit-icon {
        width: 40px;
        height: 40px;
        min-width: 40px;
    }

    .benefit-icon svg {
        width: 22px;
        height: 22px;
    }

    .benefit-item strong {
        font-size: 13px;
        line-height: 1.3;
    }

    .benefit-item span {
        font-size: 11.5px;
        line-height: 1.35;
        margin-top: 3px;
    }


    /* ----- Produk (2 kolom ala katalog) ----- */

    .products-section { padding: 56px 6%; }

    .products-layout {
        grid-template-columns: 1fr;
        gap: 26px;
    }

    .products-intro .section-title { font-size: clamp(26px, 7vw, 32px); }

    .products-link {
        width: 100%;
        max-width: 340px;
        margin-top: 18px;
        justify-content: space-between;
    }

    .products-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
    }

    .product-image { height: 150px; }

    .product-info { padding: 12px; }

    .product-category { font-size: 10px; }

    .product-name {
        font-size: 13px;
        line-height: 1.4;
        margin: 6px 0;
        min-height: 2.8em;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .product-price { font-size: 12.5px; }

    .product-detail {
        margin-top: 10px;
        font-size: 11.5px;
    }


    /* ----- Tentang ----- */

    .about-section { grid-template-columns: 1fr; }

    .about-image {
        min-height: 240px;
        padding: 20px;
    }

    .about-image img {
        min-height: 0;
        max-height: 240px;
    }

    .about-content { padding: 36px 7% 44px; }

    .about-content .section-title { font-size: clamp(26px, 7vw, 32px); }

    .about-content p {
        font-size: 14.5px;
        line-height: 1.8;
    }

    .about-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
        margin-top: 26px;
        padding-top: 22px;
        border-top: 1px solid rgba(255,255,255,.15);
    }

    .about-stat strong { font-size: 26px; }

    .about-stat span {
        display: block;
        font-size: 11.5px;
        line-height: 1.4;
    }


    /* ----- Mitra ----- */

    .partners-section { padding: 52px 6%; }

    .partners-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
    }

    .partner-card {
        min-height: 104px;
        padding: 16px 12px;
    }

    .partner-card img {
        max-width: 110px;
        max-height: 48px;
        margin-bottom: 8px;
    }

    .partner-card strong { font-size: 12.5px; }


    /* ----- Testimoni (geser horizontal) ----- */

    .testimonials-section { padding: 52px 6%; }

    .testimonials-grid {
        display: flex;
        gap: 14px;
        max-width: none;
        margin: 0 -6vw;
        padding: 0 6vw 10px;
        overflow-x: auto;
        scroll-snap-type: x mandatory;
        scroll-padding: 0 6vw;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
    }

    .testimonials-grid::-webkit-scrollbar { display: none; }

    .testimonial-card {
        flex: 0 0 84%;
        scroll-snap-align: start;
    }

    .testimonials-grid .home-empty { flex: 0 0 calc(100vw - 12vw); }

    .testimonial-text { font-size: 13.5px; }
}


/* Perangkat sentuh: tidak ada efek hover yang "menempel", diganti umpan balik saat disentuh */

@media (hover: none) {
    .product-card:hover {
        transform: none;
        box-shadow: 0 3px 12px rgba(8,39,68,.07);
    }

    .product-card:hover .product-image img { transform: none; }

    .partner-card:hover {
        transform: none;
        border-color: #EEE7DB;
    }

    .product-card:active { transform: scale(.985); }
}


/* =====================================
   RESPONSIVE SMALL MOBILE
===================================== */

@media(max-width: 430px) {
    .hero-left { padding-top: 100px; }

    .hero-content h1 { font-size: clamp(32px, 10.5vw, 40px); }

    .hero-product-frame { height: 225px; }

    .product-image { height: 132px; }

    .about-stats { gap: 8px; }

    .about-stat strong { font-size: 24px; }
}

@media(max-width: 360px) {
    .benefit-strip { grid-template-columns: 1fr; }

    .benefit-item:nth-last-child(-n+2) { border-bottom: 1px solid #F0DDC2; }

    .benefit-item:last-child { border-bottom: none; }
}

@media(max-width: 340px) {
    .products-grid { grid-template-columns: 1fr; }

    .product-image { height: 170px; }
}

@media(prefers-reduced-motion: reduce) {
    html { scroll-behavior: auto; }

    .hero-track { transition: none; }

    .hero-slide.is-active .hero-content > *,
    .hero-slide.is-active .hero-product-image { animation: none; }

    .reveal {
        opacity: 1;
        transform: none;
        transition: none;
    }
}
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<?php
    /* ---------- Data tambahan (aman jika controller lama belum mengirimnya) ---------- */
    $categories = $categories ?? collect();
    $services   = $services ?? collect();
    $portfolios = $portfolios ?? collect();
    $articles   = $articles ?? collect();

    /* Ambil nilai pertama yang terisi dari beberapa kemungkinan nama kolom */
    $pick = function ($model, array $keys, $default = null) {
        foreach ($keys as $key) {
            $value = data_get($model, $key);

            if (is_scalar($value) && $value !== '') {
                return $value;
            }
        }

        return $default;
    };

    /* Ubah path gambar di storage menjadi URL */
    $imageUrl = function ($path, $fallback = null) {
        if (empty($path)) {
            return $fallback;
        }

        if (preg_match('#^https?://#i', (string) $path)) {
            return $path;
        }

        return asset('storage/' . ltrim((string) $path, '/'));
    };

    /* Link ke halaman detail jika route tersedia, jika tidak ke halaman daftar */
    $linkTo = function ($showRoute, $indexRoute, $model) use ($pick) {
        $slug = $pick($model, ['slug']);

        if ($slug && \Illuminate\Support\Facades\Route::has($showRoute)) {
            try {
                return route($showRoute, $slug);
            } catch (\Throwable $e) {
                // gunakan halaman daftar
            }
        }

        return route($indexRoute);
    };

    /* Gambar cadangan jika data belum punya foto */
    $fallbackImages = [
        asset('images/products/01_teak_stool_with_4_legs.png'),
        asset('images/products/07_17_teak_side_table_with_branch_legs.png'),
        asset('images/products/16_teak_live_edge_corner_shelf_set_of_2.png'),
        asset('images/products/05_teak_plant_stand_24.png'),
    ];

    /* Link WhatsApp (nomor diatur di config/terrawood.php) */
    $waNumber = config('terrawood.whatsapp', '6281234567890');
    $waUrl    = 'https://wa.me/' . $waNumber . '?text='
              . rawurlencode('Halo TERRAWOOD, saya ingin berkonsultasi mengenai furnitur.');
?>

<div class="home-page">

<?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<section class="hero" id="heroSlider" aria-roledescription="carousel" aria-label="Koleksi unggulan TERRAWOOD">

    <div class="hero-track" id="heroTrack">

        

        <div class="hero-slide">

            <div class="hero-left">

                <div class="hero-content">

                    <p class="hero-label">
                        TERRAWOOD SIGNATURE COLLECTION
                    </p>

                    <h1>
                        Nature in
                        <br>
                        Every <span>Detail.</span>
                    </h1>

                    <p class="hero-description">
                        Hadirkan kehangatan alam ke dalam ruang Anda.
                        Temukan furnitur dan dekorasi kayu pilihan
                        dengan karakter alami serta sentuhan pengerjaan
                        yang memperhatikan setiap detail.
                    </p>

                    <a href="<?php echo e(route('catalog.index')); ?>" class="hero-button">
                        Jelajahi Koleksi <span class="btn-arrow" aria-hidden="true">→</span>
                    </a>

                    <div class="hero-kicker">
                        CRAFTING COMFORT WITH NATURE
                    </div>

                </div>

            </div>

            <div class="hero-right">

                <div class="hero-product-frame">
                    <img
                        src="<?php echo e(asset('images/products/01_teak_stool_with_4_legs.png')); ?>"
                        alt="Teak Stool with 4 Legs - Produk TERRAWOOD"
                        class="hero-product-image"
                        width="800"
                        height="600"
                        loading="eager"
                        fetchpriority="high"
                        decoding="async"
                    >
                </div>

                <span class="hero-image-caption">
                    Natural teak wood collection
                </span>

            </div>

        </div>


        

        <div class="hero-slide">

            <div class="hero-left">

                <div class="hero-content">

                    <p class="hero-label">
                        TIMELESS WOODEN FURNITURE
                    </p>

                    <h1>
                        Crafted for
                        <br>
                        <span>Your Space.</span>
                    </h1>

                    <p class="hero-description">
                        Setiap ruang memiliki ceritanya sendiri.
                        Lengkapi hunian dengan furnitur kayu yang
                        menghadirkan karakter, fungsi, dan keindahan
                        natural dalam satu kesatuan.
                    </p>

                    <a href="<?php echo e(route('catalog.index')); ?>" class="hero-button">
                        Temukan Produk <span class="btn-arrow" aria-hidden="true">→</span>
                    </a>

                    <div class="hero-kicker">
                        DESIGNED TO FEEL LIKE HOME
                    </div>

                </div>

            </div>

            <div class="hero-right">

                <div class="hero-product-frame">
                    <img
                        src="<?php echo e(asset('images/products/07_17_teak_side_table_with_branch_legs.png')); ?>"
                        alt="17 Teak Side Table with Branch Legs - Produk TERRAWOOD"
                        class="hero-product-image"
                        width="800"
                        height="600"
                        loading="lazy"
                        decoding="async"
                    >
                </div>

                <span class="hero-image-caption">
                    Handcrafted side table
                </span>

            </div>

        </div>


        

        <div class="hero-slide">

            <div class="hero-left">

                <div class="hero-content">

                    <p class="hero-label">
                        CRAFTING COMFORT WITH NATURE
                    </p>

                    <h1>
                        Bring Nature
                        <br>
                        <span>Closer Home.</span>
                    </h1>

                    <p class="hero-description">
                        Dari furnitur hingga dekorasi, TERRAWOOD
                        menghadirkan pilihan produk yang membantu
                        menciptakan suasana ruang yang lebih hangat,
                        nyaman, dan berkarakter.
                    </p>

                    <a href="#tentang" class="hero-button">
                        Tentang TERRAWOOD <span class="btn-arrow" aria-hidden="true">→</span>
                    </a>

                    <div class="hero-kicker">
                        PT. TERRAWOOD FURNITUR DEKORASI
                    </div>

                </div>

            </div>

            <div class="hero-right">

                <div class="hero-product-frame">
                    <img
                        src="<?php echo e(asset('images/products/16_teak_live_edge_corner_shelf_set_of_2.png')); ?>"
                        alt="Teak Live Edge Corner Shelf - Produk TERRAWOOD"
                        class="hero-product-image"
                        width="800"
                        height="600"
                        loading="lazy"
                        decoding="async"
                    >
                </div>

                <span class="hero-image-caption">
                    Natural home accents
                </span>

            </div>

        </div>

    </div>


    <div class="hero-controls">

        <div class="hero-dots" id="heroDots"></div>

        <div class="hero-counter">
            <strong id="heroCurrent">01</strong> / 03
        </div>

        <button type="button" id="heroPrev" aria-label="Slide sebelumnya">
            ←
        </button>

        <button type="button" id="heroNext" aria-label="Slide berikutnya">
            →
        </button>

    </div>

</section>




<section class="benefit-strip">

    <div class="benefit-item">

        <div class="benefit-icon">
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M11 20C5 17 4 11 7 5c5 0 9 3 9 8 0 3-2 6-5 7Z"/>
                <path d="M5 21c2-5 6-8 12-11"/>
                <path d="M16 4c2-1 4-1 5-1 0 2 0 4-1 6"/>
            </svg>
        </div>

        <div>
            <strong>Material Berkualitas</strong>
            <span>dan Ramah Lingkungan</span>
        </div>

    </div>


    <div class="benefit-item">

        <div class="benefit-icon">
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="m12 3 8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7l8-4Z"/>
                <path d="m8.5 12 2.3 2.3 4.8-5"/>
            </svg>
        </div>

        <div>
            <strong>Desain Modern</strong>
            <span>dan Elegan</span>
        </div>

    </div>


    <div class="benefit-item">

        <div class="benefit-icon">
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M4 13v-2a8 8 0 0 1 16 0v2"/>
                <path d="M4 13h3v6H6a2 2 0 0 1-2-2v-4Z"/>
                <path d="M20 13h-3v6h1a2 2 0 0 0 2-2v-4Z"/>
                <path d="M17 19c-1 2-3 2-5 2"/>
            </svg>
        </div>

        <div>
            <strong>Layanan Profesional</strong>
            <span>dan Responsif</span>
        </div>

    </div>


    <div class="benefit-item">

        <div class="benefit-icon">
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <circle cx="12" cy="12" r="9"/>
                <path d="M3 12h18"/>
                <path d="M12 3a14 14 0 0 1 0 18"/>
                <path d="M12 3a14 14 0 0 0 0 18"/>
                <path d="m16 8 2 2 3-3"/>
            </svg>
        </div>

        <div>
            <strong>Worldwide Shipping</strong>
            <span>Safe delivery across the world</span>
        </div>

    </div>

</section>




<?php if($categories->isNotEmpty()): ?>
<section class="categories-section" id="kategori">

    <div class="section-heading center">

        <p class="section-label">
            Koleksi Kami
        </p>

        <h2 class="section-title">
            Belanja Berdasarkan Kategori
        </h2>

        <p class="section-description">
            Pilih jenis furnitur dan dekorasi yang Anda cari.
        </p>

    </div>

    <div class="categories-grid">

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $catImage = $imageUrl(
                    $pick($category, ['image', 'thumbnail', 'photo', 'cover']),
                    $fallbackImages[$loop->index % count($fallbackImages)]
                );
            ?>

            <a
                href="<?php echo e(route('catalog.index', ['category' => $category->id])); ?>"
                class="category-tile"
            >
                <img
                    src="<?php echo e($catImage); ?>"
                    alt="<?php echo e($category->name); ?>"
                    width="600"
                    height="450"
                    loading="lazy"
                    decoding="async"
                >

                <span class="category-label">
                    <span>
                        <strong><?php echo e($category->name); ?></strong>
                        <small>Lihat koleksi</small>
                    </span>
                    <span class="btn-arrow" aria-hidden="true">→</span>
                </span>
            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</section>
<?php endif; ?>




<section class="products-section" id="katalog">

    <div class="products-layout">

        <div class="products-intro">

            <p class="section-label">
                Produk Unggulan
            </p>

            <h2 class="section-title">
                Koleksi Terbaik untuk Hunian Anda
            </h2>

            <p class="section-description">
                Temukan berbagai pilihan furnitur dengan desain modern
                dan kualitas premium.
            </p>

            <a href="<?php echo e(route('catalog.index')); ?>" class="products-link">
                Lihat Semua Produk <span class="btn-arrow" aria-hidden="true">→</span>
            </a>

        </div>


        <div class="products-grid">

            <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="product-card">

                    <div class="product-image">

                        <?php if($product->image): ?>

                            <img
                                src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                alt="<?php echo e($product->name); ?>"
                                width="400"
                                height="300"
                                loading="lazy"
                                decoding="async"
                            >

                        <?php else: ?>

                            <img
                                src="<?php echo e(asset('images/products/01_teak_stool_with_4_legs.png')); ?>"
                                alt="Koleksi produk kayu TERRAWOOD"
                                width="400"
                                height="300"
                                loading="lazy"
                                decoding="async"
                            >

                        <?php endif; ?>

                    </div>


                    <div class="product-info">

                        <div class="product-category">
                            <?php echo e($product->category?->name ?? 'Furniture'); ?>

                        </div>

                        <h3 class="product-name">
                            <?php echo e($product->name); ?>

                        </h3>

                        <div class="product-price">
                            <?php if(!empty($product->price)): ?>
                                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                            <?php else: ?>
                                Hubungi kami
                            <?php endif; ?>
                        </div>

                        <a
                            href="<?php echo e(route('catalog.show', $product->slug)); ?>"
                            class="product-detail"
                        >
                            Lihat Detail <span aria-hidden="true">→</span>
                        </a>

                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="product-empty">
                    <h3>Produk Unggulan Segera Hadir</h3>
                    <p>Kami sedang menyiapkan koleksi terbaik untuk Anda.</p>
                </div>

            <?php endif; ?>

        </div>

    </div>

</section>




<section class="statement-section">

    <div class="statement-inner">

        <p class="section-label">
            Filosofi Kami
        </p>

        <h2 class="statement-quote">
            Setiap serat kayu punya <em>cerita.</em>
            Kami menjaganya tetap utuh di setiap sentuhan.
        </h2>

        <div class="statement-points">

            <div>
                <strong>Material Alami</strong>
                <span>Kayu pilihan dengan karakter yang tidak pernah sama.</span>
            </div>

            <div>
                <strong>Dikerjakan Teliti</strong>
                <span>Setiap detail diperhatikan hingga tahap akhir.</span>
            </div>

            <div>
                <strong>Tahan Lama</strong>
                <span>Dirancang untuk menemani hunian Anda bertahun-tahun.</span>
            </div>

        </div>

    </div>

</section>




<?php if($services->isNotEmpty()): ?>
<section class="services-section" id="layanan">

    <div class="section-heading split">

        <div>

            <p class="section-label">
                Layanan
            </p>

            <h2 class="section-title">
                Solusi untuk Setiap Ruang
            </h2>

        </div>

        <a href="<?php echo e(route('services.index')); ?>" class="text-link">
            Lihat Semua Layanan <span aria-hidden="true">→</span>
        </a>

    </div>

    <div class="services-grid">

        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $svTitle = $pick($service, ['name', 'title'], 'Layanan TERRAWOOD');
                $svText  = $pick($service, ['short_description', 'excerpt', 'summary', 'description'], '');
                $svDesc  = \Illuminate\Support\Str::limit(trim(strip_tags(html_entity_decode((string) $svText))), 110);
                $svImage = $imageUrl($pick($service, ['image', 'thumbnail', 'photo']));
                $svUrl   = $linkTo('services.show', 'services.index', $service);
            ?>

            <a href="<?php echo e($svUrl); ?>" class="service-card">

                <span class="service-index" aria-hidden="true"><?php echo e(str_pad($loop->iteration, 2, '0', STR_PAD_LEFT)); ?></span>

                <?php if($svImage): ?>

                    <span class="service-media">
                        <img
                            src="<?php echo e($svImage); ?>"
                            alt="<?php echo e($svTitle); ?>"
                            width="400"
                            height="280"
                            loading="lazy"
                            decoding="async"
                        >
                    </span>

                <?php else: ?>

                    <span class="service-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24">
                            <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                        </svg>
                    </span>

                <?php endif; ?>

                <h3><?php echo e($svTitle); ?></h3>

                <?php if($svDesc !== ''): ?>
                    <p><?php echo e($svDesc); ?></p>
                <?php endif; ?>

                <span class="service-more">
                    Selengkapnya <span aria-hidden="true">→</span>
                </span>

            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</section>
<?php endif; ?>




<?php if($portfolios->isNotEmpty()): ?>
<section class="portfolio-section" id="proyek">

    <div class="section-heading split">

        <div>

            <p class="section-label">
                Portofolio
            </p>

            <h2 class="section-title">
                Proyek Pilihan Kami
            </h2>

        </div>

        <a href="<?php echo e(route('portfolios.index')); ?>" class="text-link">
            Lihat Semua Proyek <span aria-hidden="true">→</span>
        </a>

    </div>

    <div class="portfolio-grid">

        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $ptTitle = $pick($portfolio, ['title', 'name', 'project_name'], 'Proyek TERRAWOOD');
                $ptMeta  = $pick($portfolio, ['location', 'client_name', 'client', 'year']);
                $ptPath  = $pick($portfolio, ['image', 'thumbnail', 'photo', 'cover', 'featured_image']);
                $ptImage = $imageUrl($ptPath, $fallbackImages[$loop->index % count($fallbackImages)]);
                $ptUrl   = $linkTo('portfolios.show', 'portfolios.index', $portfolio);
            ?>

            <a href="<?php echo e($ptUrl); ?>" class="portfolio-item">

                <img
                    src="<?php echo e($ptImage); ?>"
                    alt="<?php echo e($ptTitle); ?>"
                    class="<?php echo e($ptPath ? '' : 'is-fallback'); ?>"
                    width="800"
                    height="600"
                    loading="lazy"
                    decoding="async"
                >

                <span class="portfolio-caption">
                    <strong><?php echo e($ptTitle); ?></strong>
                    <?php if($ptMeta): ?>
                        <small><?php echo e($ptMeta); ?></small>
                    <?php endif; ?>
                </span>

            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</section>
<?php endif; ?>




<section class="steps-section" id="cara-pesan">

    <div class="section-heading center">

        <p class="section-label">
            Cara Pemesanan
        </p>

        <h2 class="section-title">
            Pesan Furnitur dalam 4 Langkah
        </h2>

        <p class="section-description">
            Proses yang sederhana dari memilih hingga produk sampai di tempat Anda.
        </p>

    </div>

    <div class="steps-grid">

        <div class="step-item">

            <div class="step-badge">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="m21 21-4.3-4.3"/>
                </svg>
                <span class="step-number">1</span>
            </div>

            <div class="step-text">
                <h3>Pilih Produk</h3>
                <p>Jelajahi katalog dan pilih furnitur yang sesuai dengan kebutuhan ruang Anda.</p>
            </div>

        </div>

        <div class="step-item">

            <div class="step-badge">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                <span class="step-number">2</span>
            </div>

            <div class="step-text">
                <h3>Konsultasi</h3>
                <p>Hubungi kami via WhatsApp untuk membahas ukuran, material, dan finishing.</p>
            </div>

        </div>

        <div class="step-item">

            <div class="step-badge">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                </svg>
                <span class="step-number">3</span>
            </div>

            <div class="step-text">
                <h3>Konfirmasi &amp; Produksi</h3>
                <p>Setelah kesepakatan, pesanan diproses dan dikerjakan dengan teliti.</p>
            </div>

        </div>

        <div class="step-item">

            <div class="step-badge">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/>
                    <path d="M15 18H9"/>
                    <path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/>
                    <circle cx="17" cy="18" r="2"/>
                    <circle cx="7" cy="18" r="2"/>
                </svg>
                <span class="step-number">4</span>
            </div>

            <div class="step-text">
                <h3>Pengiriman</h3>
                <p>Produk dikemas dengan aman dan dikirim sampai ke lokasi Anda.</p>
            </div>

        </div>

    </div>

    <div class="steps-cta">

        <a href="<?php echo e($waUrl); ?>" class="hero-button" target="_blank" rel="noopener">
            Mulai Konsultasi <span class="btn-arrow" aria-hidden="true">→</span>
        </a>

    </div>

</section>




<section class="about-section" id="tentang">

    <div class="about-image">

        <img
            src="<?php echo e(asset('images/products/05_teak_plant_stand_24.png')); ?>"
            alt="Teak Plant Stand - Produk TERRAWOOD"
            width="600"
            height="450"
            loading="lazy"
            decoding="async"
        >

    </div>


    <div class="about-content">

        <p class="section-label">
            About Our Company
        </p>

        <h2 class="section-title">
            Tentang TERRAWOOD
        </h2>

        <p>
            PT. TERRAWOOD FURNITUR DEKORASI merupakan perusahaan
            yang bergerak di bidang furnitur dan dekorasi interior.
            Kami menghadirkan produk berkualitas dengan desain
            modern, elegan, dan sentuhan alami untuk menciptakan
            ruang yang nyaman serta bernilai estetika.
        </p>


        
        <div class="about-stats">

            <div class="about-stat">
                <strong data-count="10" data-suffix="+">10+</strong>
                <span>Tahun Pengalaman</span>
            </div>

            <div class="about-stat">
                <strong data-count="5" data-suffix="K+">5K+</strong>
                <span>Pelanggan Puas</span>
            </div>

            <div class="about-stat">
                <strong data-count="200" data-suffix="+">200+</strong>
                <span>Proyek Selesai</span>
            </div>

        </div>

    </div>

</section>




<section class="partners-section" id="mitra">

    <div class="section-heading center">

        <p class="section-label">
            Our Partners
        </p>

        <h2 class="section-title">
            Klien & Mitra Kami
        </h2>

        <p class="section-description">
            Membangun hubungan dan kerja sama untuk hasil terbaik.
        </p>

    </div>


    <div class="partners-grid">

        <?php $__empty_1 = true; $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="partner-card">

                <?php if($partner->logo): ?>

                    <img
                        src="<?php echo e(asset('storage/' . $partner->logo)); ?>"
                        alt="<?php echo e($partner->name); ?>"
                        width="140"
                        height="60"
                        loading="lazy"
                        decoding="async"
                    >

                <?php endif; ?>

                <strong><?php echo e($partner->name); ?></strong>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="home-empty">
                Informasi mitra akan segera tersedia.
            </div>

        <?php endif; ?>

    </div>

</section>




<section class="testimonials-section" id="testimoni">

    <div class="section-heading">

        <p class="section-label">
            Testimoni Pelanggan
        </p>

        <h2 class="section-title">
            Apa Kata Mereka?
        </h2>

        <p class="section-description">
            Kepuasan pelanggan adalah prioritas utama kami.
        </p>

    </div>


    <div class="testimonials-grid">

        <?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="testimonial-card">

                <div class="testimonial-stars" aria-label="Rating <?php echo e((int) $testimonial->rating); ?> dari 5">

                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <?php echo e($i <= $testimonial->rating ? '★' : '☆'); ?>

                    <?php endfor; ?>

                </div>


                <p class="testimonial-text">
                    “<?php echo e($testimonial->testimonial); ?>”
                </p>


                <div class="testimonial-person">

                    <?php if($testimonial->customer_photo): ?>

                        <img
                            src="<?php echo e(asset('storage/' . $testimonial->customer_photo)); ?>"
                            alt="<?php echo e($testimonial->customer_name); ?>"
                            width="42"
                            height="42"
                            loading="lazy"
                            decoding="async"
                        >

                    <?php else: ?>

                        <div class="testimonial-avatar" aria-hidden="true">
                            <?php echo e(mb_strtoupper(mb_substr($testimonial->customer_name ?? 'T', 0, 1))); ?>

                        </div>

                    <?php endif; ?>


                    <div>

                        <strong>
                            <?php echo e($testimonial->customer_name); ?>

                        </strong>

                        <span>
                            Pelanggan TERRAWOOD
                        </span>

                    </div>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="home-empty">
                Testimoni pelanggan akan segera ditampilkan.
            </div>

        <?php endif; ?>

    </div>

</section>




<?php if($articles->isNotEmpty()): ?>
<section class="articles-section" id="artikel">

    <div class="section-heading split">

        <div>

            <p class="section-label">
                Inspirasi
            </p>

            <h2 class="section-title">
                Artikel &amp; Tips Terbaru
            </h2>

        </div>

        <a href="<?php echo e(route('articles.index')); ?>" class="text-link">
            Lihat Semua Artikel <span aria-hidden="true">→</span>
        </a>

    </div>

    <div class="articles-grid">

        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $arTitle   = $pick($article, ['title'], 'Artikel TERRAWOOD');
                $arPath    = $pick($article, ['image', 'thumbnail', 'cover', 'featured_image']);
                $arImage   = $imageUrl($arPath, $fallbackImages[$loop->index % count($fallbackImages)]);
                $arText    = $pick($article, ['excerpt', 'summary', 'description', 'content', 'body'], '');
                $arExcerpt = \Illuminate\Support\Str::limit(trim(strip_tags(html_entity_decode((string) $arText))), 120);
                $arDate    = $article->created_at?->locale('id')->translatedFormat('d F Y');
                $arUrl     = $linkTo('articles.show', 'articles.index', $article);
            ?>

            <a href="<?php echo e($arUrl); ?>" class="article-card">

                <span class="article-thumb">
                    <img
                        src="<?php echo e($arImage); ?>"
                        alt="<?php echo e($arTitle); ?>"
                        class="<?php echo e($arPath ? '' : 'is-fallback'); ?>"
                        width="640"
                        height="400"
                        loading="lazy"
                        decoding="async"
                    >
                </span>

                <span class="article-body">

                    <?php if($arDate): ?>
                        <span class="article-date"><?php echo e($arDate); ?></span>
                    <?php endif; ?>

                    <h3><?php echo e($arTitle); ?></h3>

                    <?php if($arExcerpt !== ''): ?>
                        <p><?php echo e($arExcerpt); ?></p>
                    <?php endif; ?>

                    <span class="article-more">
                        Baca selengkapnya <span aria-hidden="true">→</span>
                    </span>

                </span>

            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</section>
<?php endif; ?>




<section class="cta-section">

    <div class="cta-box">

        <div>

            <p class="cta-label">
                Furnitur Custom
            </p>

            <h2>
                Punya Desain Sendiri? Wujudkan Bersama TERRAWOOD.
            </h2>

            <p>
                Ceritakan kebutuhan ruang Anda, dan tim kami siap membantu
                dari konsep hingga produk jadi.
            </p>

        </div>

        <div class="cta-actions">

            <a href="<?php echo e($waUrl); ?>" class="hero-button" target="_blank" rel="noopener">
                Konsultasi via WhatsApp <span class="btn-arrow" aria-hidden="true">→</span>
            </a>

            <a href="<?php echo e(route('catalog.index')); ?>" class="cta-secondary">
                Lihat Katalog
            </a>

        </div>

    </div>

</section>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>




<script>
document.addEventListener('DOMContentLoaded', function () {

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;


    /* =====================================
       ANIMASI MUNCUL SAAT SCROLL
       (konten tetap terlihat jika JS gagal)
    ===================================== */

    if ('IntersectionObserver' in window && !reduceMotion) {

        const revealObserver = new IntersectionObserver(function (entries) {

            entries.forEach(function (entry) {

                if (entry.isIntersecting) {
                    entry.target.classList.add('in');
                    revealObserver.unobserve(entry.target);
                }

            });

        }, { threshold: 0.12 });

        document.querySelectorAll(
            '.benefit-strip, .products-intro, .products-grid, .about-content, ' +
            '.partners-section .section-heading, .partners-grid, ' +
            '.testimonials-section .section-heading, .testimonials-grid, ' +
            '.categories-section .section-heading, .categories-grid, .statement-inner, ' +
            '.services-section .section-heading, .services-grid, ' +
            '.portfolio-section .section-heading, .portfolio-grid, ' +
            '.steps-section .section-heading, .steps-grid, .steps-cta, ' +
            '.articles-section .section-heading, .articles-grid, .cta-box'
        ).forEach(function (element) {
            element.classList.add('reveal');
            revealObserver.observe(element);
        });

    }


    /* =====================================
       ANGKA STATISTIK (menghitung naik)
    ===================================== */

    const counters = document.querySelectorAll('[data-count]');

    function animateCount(element) {

        const target = parseFloat(element.dataset.count);
        const suffix = element.dataset.suffix || '';

        if (isNaN(target)) return;

        const duration = 1400;
        const startTime = performance.now();

        function tick(now) {

            const progress = Math.min((now - startTime) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);

            element.textContent = Math.round(target * eased) + suffix;

            if (progress < 1) {
                window.requestAnimationFrame(tick);
            }

        }

        window.requestAnimationFrame(tick);

    }

    if (counters.length && 'IntersectionObserver' in window && !reduceMotion) {

        const counterObserver = new IntersectionObserver(function (entries) {

            entries.forEach(function (entry) {

                if (entry.isIntersecting) {
                    animateCount(entry.target);
                    counterObserver.unobserve(entry.target);
                }

            });

        }, { threshold: 0.6 });

        counters.forEach(function (counter) {
            counterObserver.observe(counter);
        });

    }


    /* =====================================
       HERO SLIDER
    ===================================== */

    const slider = document.getElementById('heroSlider');

    if (!slider) return;

    const track = document.getElementById('heroTrack');

    const slides = track.querySelectorAll('.hero-slide');

    const currentNumber = document.getElementById('heroCurrent');

    const prevButton = document.getElementById('heroPrev');

    const nextButton = document.getElementById('heroNext');

    const dotsWrap = document.getElementById('heroDots');

    const AUTO_SLIDE_DELAY = 5500;

    let currentIndex = 0;

    let sliderInterval = null;

    const totalSlides = slides.length;

    const dots = [];


    slides.forEach(function (slide, index) {

        const dot = document.createElement('button');

        dot.type = 'button';
        dot.setAttribute('aria-label', 'Ke slide ' + (index + 1));

        dot.addEventListener('click', function () {
            showSlide(index);
            startAutoSlide();
        });

        dotsWrap.appendChild(dot);
        dots.push(dot);

    });


    function showSlide(index) {

        currentIndex = (index + totalSlides) % totalSlides;

        track.style.transform =
            'translateX(-' + (currentIndex * 100) + '%)';

        currentNumber.textContent =
            String(currentIndex + 1).padStart(2, '0');

        slides.forEach(function (slide, i) {
            const isActive = i === currentIndex;
            slide.classList.toggle('is-active', isActive);
            slide.inert = !isActive;
            slide.setAttribute('aria-hidden', isActive ? 'false' : 'true');
        });

        dots.forEach(function (dot, i) {
            const isActive = i === currentIndex;
            dot.classList.toggle('active', isActive);
            dot.setAttribute('aria-current', isActive ? 'true' : 'false');
        });

    }


    function nextSlide() {
        showSlide(currentIndex + 1);
    }


    function previousSlide() {
        showSlide(currentIndex - 1);
    }


    function stopAutoSlide() {
        clearInterval(sliderInterval);
        sliderInterval = null;
    }


    function startAutoSlide() {

        stopAutoSlide();

        if (reduceMotion || document.hidden) return;

        sliderInterval = setInterval(nextSlide, AUTO_SLIDE_DELAY);

    }


    nextButton.addEventListener('click', function () {

        nextSlide();

        startAutoSlide();

    });


    prevButton.addEventListener('click', function () {

        previousSlide();

        startAutoSlide();

    });


    slider.addEventListener('mouseenter', stopAutoSlide);

    slider.addEventListener('mouseleave', startAutoSlide);

    slider.addEventListener('focusin', stopAutoSlide);

    slider.addEventListener('focusout', startAutoSlide);


    /* Berhenti saat tab tidak aktif, lanjut saat kembali */

    document.addEventListener('visibilitychange', function () {

        if (document.hidden) {
            stopAutoSlide();
        } else {
            startAutoSlide();
        }

    });


    /* Geser (swipe) di layar sentuh */

    let touchStartX = 0;
    let touchStartY = 0;

    slider.addEventListener('touchstart', function (event) {

        touchStartX = event.changedTouches[0].clientX;
        touchStartY = event.changedTouches[0].clientY;

    }, { passive: true });


    slider.addEventListener('touchend', function (event) {

        const deltaX = event.changedTouches[0].clientX - touchStartX;
        const deltaY = event.changedTouches[0].clientY - touchStartY;

        if (Math.abs(deltaX) > 50 && Math.abs(deltaX) > Math.abs(deltaY) * 1.5) {

            if (deltaX < 0) {
                nextSlide();
            } else {
                previousSlide();
            }

            startAutoSlide();

        }

    }, { passive: true });


    showSlide(0);

    startAutoSlide();

});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\terrawood\resources\views/home.blade.php ENDPATH**/ ?>