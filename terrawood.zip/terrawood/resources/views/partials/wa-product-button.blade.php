{{--
    Tombol "Tanya via WhatsApp" untuk halaman detail produk.
    Pemakaian: @include('partials.wa-product-button', ['product' => $product])
    Nomor WhatsApp diambil dari config/terrawood.php
--}}
@php
    $waNumber = config('terrawood.whatsapp', '6281234567890');

    $waText = 'Halo TERRAWOOD, saya tertarik dengan produk "' . $product->name . '". '
            . 'Apakah masih tersedia dan berapa estimasi harganya?' . "\n"
            . url()->current();

    $waUrl = 'https://wa.me/' . $waNumber . '?text=' . rawurlencode($waText);
@endphp

@once
@push('styles')
<style>
.wa-product-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    background: #20C76A;
    color: #fff;
    padding: 15px 26px;
    border-radius: 30px;
    font-family: 'Inter', sans-serif;
    font-size: 14px;
    font-weight: 800;
    text-decoration: none;
    box-shadow: 0 6px 18px rgba(32,199,106,.3);
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
    transition:
        background-color .35s cubic-bezier(.22,.61,.36,1),
        transform .35s cubic-bezier(.22,.61,.36,1),
        box-shadow .35s cubic-bezier(.22,.61,.36,1);
}

.wa-product-button:hover,
.wa-product-button:focus-visible {
    background: #17A956;
    color: #fff;
    transform: translateY(-3px);
    box-shadow: 0 10px 22px rgba(32,199,106,.35);
}

.wa-product-button:active {
    transform: translateY(0) scale(.97);
    transition-duration: .12s;
}

.wa-product-button:focus-visible {
    outline: 2px solid #082744;
    outline-offset: 3px;
}

.wa-product-button svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
}

@media(max-width: 430px) {
    .wa-product-button {
        width: 100%;
    }
}
</style>
@endpush
@endonce

<a
    href="{{ $waUrl }}"
    class="wa-product-button"
    target="_blank"
    rel="noopener"
>
    <svg viewBox="0 0 32 32" aria-hidden="true">
        <path
            fill="currentColor"
            d="M16.02 3.2A12.7 12.7 0 0 0 5.1 22.38L3.4 28.6l6.37-1.67A12.7 12.7 0 1 0 16.02 3.2Zm0 23.1c-1.98 0-3.92-.53-5.62-1.53l-.4-.24-3.78.99 1.01-3.68-.26-.42a10.38 10.38 0 1 1 9.05 4.88Zm5.7-7.77c-.31-.16-1.84-.91-2.12-1.01-.29-.1-.5-.16-.71.16-.21.31-.81 1.01-.99 1.22-.18.21-.36.23-.67.08-.31-.16-1.3-.48-2.47-1.53-.91-.81-1.53-1.81-1.71-2.12-.18-.31-.02-.48.14-.64.14-.14.31-.36.47-.54.16-.18.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.71-.97-2.34-.26-.61-.52-.53-.71-.54h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.07-1.1 2.61s1.13 3.03 1.28 3.24c.16.21 2.22 3.39 5.38 4.75.75.32 1.33.51 1.78.65.75.24 1.44.2 1.98.12.6-.09 1.84-.75 2.1-1.48.26-.73.26-1.35.18-1.48-.08-.13-.29-.21-.6-.37Z"
        />
    </svg>
    Tanya via WhatsApp
</a>