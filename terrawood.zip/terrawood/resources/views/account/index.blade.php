@extends('layouts.app')

@section('title', 'Dashboard Customer | TERRAWOOD')

@section('content')

@php
    /* =====================================
       IKON (SVG)
    ===================================== */
    $ic = [
        'bell'     => '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
        'bag'      => '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" x2="21" y1="6" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
        'clock'    => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'progress' => '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
        'done'     => '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
        'check'    => '<polyline points="20 6 9 17 4 12"/>',
        'truck'    => '<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/>',
        'alert'    => '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
        'arrow'    => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
        'logout'   => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
        'x'        => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
        'support'  => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><line x1="4.93" x2="9.17" y1="4.93" y2="9.17"/><line x1="14.83" x2="19.07" y1="14.83" y2="19.07"/><line x1="14.83" x2="19.07" y1="9.17" y2="4.93"/><line x1="4.93" x2="9.17" y1="19.07" y2="14.83"/>',
    ];

    $icon = function ($name, $size = 20) use ($ic) {
        return '<svg class="acc-ic" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($ic[$name] ?? '') . '</svg>';
    };

    $waIcon = '<svg class="acc-ic" width="18" height="18" viewBox="0 0 32 32" aria-hidden="true"><path fill="currentColor" d="M16.02 3.2A12.7 12.7 0 0 0 5.1 22.38L3.4 28.6l6.37-1.67A12.7 12.7 0 1 0 16.02 3.2Zm0 23.1c-1.98 0-3.92-.53-5.62-1.53l-.4-.24-3.78.99 1.01-3.68-.26-.42a10.38 10.38 0 1 1 9.05 4.88Zm5.7-7.77c-.31-.16-1.84-.91-2.12-1.01-.29-.1-.5-.16-.71.16-.21.31-.81 1.01-.99 1.22-.18.21-.36.23-.67.08-.31-.16-1.3-.48-2.47-1.53-.91-.81-1.53-1.81-1.71-2.12-.18-.31-.02-.48.14-.64.14-.14.31-.36.47-.54.16-.18.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.71-.97-2.34-.26-.61-.52-.53-.71-.54h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.07-1.1 2.61s1.13 3.03 1.28 3.24c.16.21 2.22 3.39 5.38 4.75.75.32 1.33.51 1.78.65.75.24 1.44.2 1.98.12.6-.09 1.84-.75 2.1-1.48.26-.73.26-1.35.18-1.48-.08-.13-.29-.21-.6-.37Z"/></svg>';

    /* =====================================
       DATA PENGGUNA
    ===================================== */
    $nameParts  = preg_split('/\s+/', trim((string) $user->name), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $firstName  = $nameParts[0] ?? 'Customer';
    $initials   = '';

    foreach (array_slice($nameParts, 0, 2) as $part) {
        $initials .= mb_strtoupper(mb_substr($part, 0, 1));
    }

    if ($initials === '') {
        $initials = 'U';
    }

    $memberSince = $user->created_at?->locale('id')->translatedFormat('F Y');

    /* =====================================
       STATUS PESANAN
    ===================================== */
    $statusAlias = [
        'pending'    => 'menunggu',
        'processing' => 'diproses',
        'shipped'    => 'dikirim',
        'completed'  => 'selesai',
        'cancelled'  => 'dibatalkan',
        'canceled'   => 'dibatalkan',
    ];

    $statusLabels = [
        'menunggu'   => 'Menunggu',
        'diproses'   => 'Diproses',
        'dikirim'    => 'Dikirim',
        'selesai'    => 'Selesai',
        'dibatalkan' => 'Dibatalkan',
    ];

    $stepIndex = [
        'menunggu' => 1,
        'diproses' => 2,
        'dikirim'  => 3,
        'selesai'  => 4,
    ];

    $statusNotes = [
        'menunggu' => 'Pesanan Anda sedang menunggu konfirmasi dari tim TERRAWOOD.',
        'diproses' => 'Pesanan Anda sedang diproses dan dikerjakan dengan teliti.',
        'dikirim'  => 'Pesanan Anda sedang dalam perjalanan menuju alamat Anda.',
    ];

    $normalizeStatus = function ($raw) use ($statusAlias) {
        $key = strtolower(trim((string) $raw));

        return $statusAlias[$key] ?? $key;
    };

    $statusLabel = function ($key) use ($statusLabels) {
        return $statusLabels[$key] ?? ucfirst($key);
    };

    $statusClass = function ($key) use ($statusLabels) {
        return isset($statusLabels[$key]) ? 'status-' . $key : 'status-lain';
    };

    /* =====================================
       DATA PESANAN
    ===================================== */
    $orderItems = collect(method_exists($orders, 'items') ? $orders->items() : $orders);

    $statusCounts = $orderItems
        ->groupBy(function ($item) use ($normalizeStatus) {
            return $normalizeStatus($item->status);
        })
        ->map(function ($group) {
            return $group->count();
        });

    /* Pesanan aktif = pesanan terbaru yang belum selesai/dibatalkan (hanya di halaman 1) */
    $activeOrder = null;

    if (!method_exists($orders, 'currentPage') || $orders->currentPage() === 1) {
        $activeOrder = $orderItems->first(function ($item) use ($normalizeStatus) {
            return !in_array($normalizeStatus($item->status), ['selesai', 'dibatalkan'], true);
        });
    }

    $fallbackImage = asset('images/products/01_teak_stool_with_4_legs.png');

    $orderImage = function ($order) use ($fallbackImage) {
        $path = $order->product?->image;

        return $path ? asset('storage/' . ltrim((string) $path, '/')) : $fallbackImage;
    };

    /* =====================================
       NOTIFIKASI
    ===================================== */
    $notifications = $user->notifications()
        ->latest()
        ->take(5)
        ->get();

    $unreadCount = $user->unreadNotifications()->count();

    /* =====================================
       BANTUAN (WhatsApp) & REKOMENDASI
    ===================================== */
    $waNumber = config('terrawood.whatsapp', '6281234567890');

    $waHelpUrl = 'https://wa.me/' . $waNumber . '?text='
               . rawurlencode('Halo TERRAWOOD, saya membutuhkan bantuan terkait akun/pesanan saya.');

    $waOrderUrl = function ($orderNumber) use ($waNumber) {
        return 'https://wa.me/' . $waNumber . '?text='
             . rawurlencode('Halo TERRAWOOD, saya ingin menanyakan pesanan ' . $orderNumber . '.');
    };

    try {
        $suggestions = \App\Models\Product::where('is_featured', true)
            ->latest()
            ->take(4)
            ->get();
    } catch (\Throwable $e) {
        $suggestions = collect();
    }
@endphp

@include('partials.navbar')

<style>
    .account-page,
    .account-page *,
    .account-page *::before,
    .account-page *::after { box-sizing: border-box; }

    .account-page {
        --a-navy: #082744;
        --a-dark: #061D33;
        --a-gold: #F5A623;
        --a-orange: #FFA43A;
        --a-ivory: #F7F5EF;
        --a-text: #293747;
        --a-muted: #718096;
        --a-line: #E9E5DC;
        --a-amber: #A56800;
        --a-ease: cubic-bezier(.22, .61, .36, 1);

        min-height: 70vh;
        padding: 40px 6% 80px;
        background: var(--a-ivory);
        color: var(--a-text);
        font-family: 'Inter', sans-serif;
    }

    .account-container {
        max-width: 1250px;
        margin: 0 auto;
    }

    .account-page a { text-decoration: none; }

    .account-page a:focus-visible,
    .account-page button:focus-visible {
        outline: 2px solid var(--a-gold);
        outline-offset: 3px;
    }

    .acc-ic { display: block; flex-shrink: 0; }

    /* =====================================
       TOMBOL
    ===================================== */

    .acc-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        padding: 12px 22px;
        border: 0;
        border-radius: 999px;
        font-family: 'Manrope', 'Inter', sans-serif;
        font-size: 13px;
        font-weight: 800;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        -webkit-tap-highlight-color: transparent;
        touch-action: manipulation;
        transition:
            background-color .3s var(--a-ease),
            color .3s var(--a-ease),
            border-color .3s var(--a-ease),
            transform .3s var(--a-ease),
            box-shadow .3s var(--a-ease);
    }

    .acc-btn .acc-ic { transition: transform .3s var(--a-ease); }

    .acc-btn--gold {
        background: var(--a-gold);
        color: var(--a-navy);
        box-shadow: 0 8px 20px rgba(245,166,35,.3);
    }

    .acc-btn--navy {
        background: var(--a-navy);
        color: white;
    }

    .acc-btn--ghost {
        background: transparent;
        color: white;
        border: 1.5px solid rgba(255,255,255,.55);
    }

    .acc-btn--outline {
        background: white;
        color: var(--a-navy);
        border: 1.5px solid #DCD5C6;
    }

    .acc-btn--wa {
        background: #20C76A;
        color: white;
    }

    .acc-btn--sm {
        padding: 10px 16px;
        font-size: 12px;
    }

    .acc-btn:active {
        transform: translateY(0) scale(.97);
        transition-duration: .12s;
    }

    @media (hover: hover) {
        .acc-btn:hover { transform: translateY(-2px); }

        .acc-btn:hover .acc-ic { transform: translateX(3px); }

        .acc-btn--gold:hover { background: white; }

        .acc-btn--navy:hover {
            background: var(--a-gold);
            color: var(--a-navy);
        }

        .acc-btn--ghost:hover {
            background: white;
            color: var(--a-navy);
            border-color: white;
        }

        .acc-btn--outline:hover {
            background: #FFF9F0;
            border-color: var(--a-gold);
        }

        .acc-btn--wa:hover { background: #17A956; }
    }

    /* =====================================
       ALERT
    ===================================== */

    .account-alert {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 14px 16px;
        margin-bottom: 20px;
        border-radius: 12px;
        font-size: 14px;
        line-height: 1.6;
    }

    .account-alert > span:nth-child(2) { flex: 1; }

    .account-alert.success {
        background: #DDF5E6;
        color: #237344;
        border: 1px solid #B8E5C8;
    }

    .account-alert.error {
        background: #FFE2E2;
        color: #B42318;
        border: 1px solid #F5BABA;
    }

    .account-alert button {
        border: 0;
        background: transparent;
        color: inherit;
        cursor: pointer;
        padding: 2px;
        opacity: .7;
        transition: opacity .2s ease;
    }

    .account-alert button:hover { opacity: 1; }

    /* =====================================
       HERO PROFIL
    ===================================== */

    .account-hero {
        position: relative;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 24px;
        padding: 32px 36px;
        margin-bottom: 26px;
        border-radius: 20px;
        background: linear-gradient(115deg, #082744, #123e63);
        color: white;
        box-shadow: 0 14px 32px rgba(8,39,68,.14);
    }

    .account-hero::after {
        content: "";
        position: absolute;
        right: -90px;
        top: -120px;
        width: 300px;
        height: 300px;
        border: 1px solid rgba(245,166,35,.25);
        border-radius: 50%;
        pointer-events: none;
    }

    .hero-user {
        position: relative;
        z-index: 1;
        display: flex;
        align-items: center;
        gap: 20px;
        min-width: 0;
    }

    .hero-avatar {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 72px;
        height: 72px;
        min-width: 72px;
        border-radius: 50%;
        background: var(--a-gold);
        color: var(--a-navy);
        font-family: 'Manrope', sans-serif;
        font-size: 26px;
        font-weight: 800;
        letter-spacing: .5px;
        box-shadow: 0 0 0 5px rgba(245,166,35,.25);
    }

    .hero-eyebrow {
        margin: 0 0 6px;
        color: var(--a-gold);
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
    }

    .hero-user h1 {
        margin: 0 0 6px;
        color: white;
        font-size: clamp(22px, 2.6vw, 30px);
        font-weight: 800;
        line-height: 1.2;
    }

    .hero-user p {
        margin: 0;
        color: #D6E0E9;
        font-size: 14px;
        word-break: break-word;
    }

    .hero-actions {
        position: relative;
        z-index: 1;
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .hero-actions form { margin: 0; }

    /* =====================================
       STATISTIK
    ===================================== */

    .account-stats {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 16px;
        margin-bottom: 26px;
    }

    .acc-stat {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 20px;
        border: 1px solid var(--a-line);
        border-radius: 16px;
        background: white;
        box-shadow: 0 2px 10px rgba(8,39,68,.04);
    }

    .acc-stat--alert {
        border-color: #F3D28F;
        background: linear-gradient(180deg, #FFFAF0, #ffffff);
    }

    .acc-stat-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 46px;
        height: 46px;
        min-width: 46px;
        border-radius: 12px;
        background: #FFF3DC;
        color: #B87308;
    }

    .acc-stat-label {
        display: block;
        color: var(--a-muted);
        font-size: 12.5px;
        font-weight: 600;
    }

    .acc-stat strong {
        display: block;
        margin-top: 3px;
        color: var(--a-navy);
        font-family: 'Manrope', sans-serif;
        font-size: 28px;
        font-weight: 800;
        line-height: 1.1;
        font-variant-numeric: tabular-nums;
    }

    .acc-stat--alert strong { color: #B87308; }

    /* =====================================
       GRID UTAMA
    ===================================== */

    .account-grid {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 350px;
        grid-template-areas:
            "tracker notif"
            "orders  notif"
            "orders  help";
        gap: 22px;
        align-items: start;
    }

    .account-grid.no-tracker {
        grid-template-areas:
            "orders notif"
            "orders help";
    }

    .area-tracker { grid-area: tracker; }
    .area-notif   { grid-area: notif; }
    .area-orders  { grid-area: orders; }
    .area-help    { grid-area: help; }

    .acc-card {
        min-width: 0;
        padding: 26px;
        border: 1px solid var(--a-line);
        border-radius: 18px;
        background: white;
        box-shadow: 0 2px 10px rgba(8,39,68,.04);
    }

    .acc-card-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 18px;
    }

    .acc-card-head h2 {
        margin: 0;
        color: var(--a-navy);
        font-size: 19px;
        font-weight: 800;
    }

    /* =====================================
       STATUS BADGE
    ===================================== */

    .status {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 999px;
        font-size: 11.5px;
        font-weight: 800;
        white-space: nowrap;
    }

    .status::before {
        content: "";
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: currentColor;
    }

    .status-menunggu   { background: #FFF1D6; color: #A56800; }
    .status-diproses   { background: #E1EDFF; color: #2456A6; }
    .status-dikirim    { background: #E8E1FF; color: #6743A5; }
    .status-selesai    { background: #DDF5E6; color: #237344; }
    .status-dibatalkan { background: #FFE2E2; color: #B42318; }
    .status-lain       { background: #EEF1F4; color: #5B6775; }

    /* =====================================
       PELACAK PESANAN AKTIF
    ===================================== */

    .tracker-card { border-top: 4px solid var(--a-gold); }

    .tracker-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 14px;
        margin-bottom: 26px;
    }

    .tracker-order {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
    }

    .tracker-thumb {
        width: 56px;
        height: 56px;
        min-width: 56px;
        padding: 4px;
        border-radius: 12px;
        object-fit: contain;
        background: #ECE9E1;
    }

    .tracker-eyebrow {
        display: block;
        margin-bottom: 4px;
        color: var(--a-amber);
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 1.2px;
        text-transform: uppercase;
    }

    .tracker-order h2 {
        margin: 0;
        color: var(--a-navy);
        font-size: 17px;
        font-weight: 800;
        line-height: 1.3;
    }

    .tracker-order p {
        margin: 3px 0 0;
        color: var(--a-muted);
        font-size: 12.5px;
    }

    .tracker-steps {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
    }

    .t-step {
        position: relative;
        text-align: center;
    }

    .t-step::before {
        content: "";
        position: absolute;
        top: 19px;
        left: -50%;
        right: 50%;
        height: 3px;
        background: #E6E0D3;
    }

    .t-step:first-child::before { display: none; }

    .t-step.is-done::before,
    .t-step.is-current::before { background: var(--a-navy); }

    .t-dot {
        position: relative;
        z-index: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        margin: 0 auto 10px;
        border: 2px solid #E6E0D3;
        border-radius: 50%;
        background: white;
        color: #B7B0A1;
    }

    .t-step.is-done .t-dot {
        border-color: var(--a-navy);
        background: var(--a-navy);
        color: white;
    }

    .t-step.is-current .t-dot {
        border-color: var(--a-gold);
        background: var(--a-gold);
        color: var(--a-navy);
        box-shadow: 0 0 0 5px rgba(245,166,35,.25);
        animation: trackerPulse 2s ease-in-out infinite;
    }

    .t-label {
        display: block;
        color: var(--a-muted);
        font-size: 12px;
        font-weight: 700;
    }

    .t-step.is-done .t-label,
    .t-step.is-current .t-label { color: var(--a-navy); }

    @keyframes trackerPulse {
        0%, 100% { box-shadow: 0 0 0 5px rgba(245,166,35,.25); }
        50%      { box-shadow: 0 0 0 9px rgba(245,166,35,.08); }
    }

    .tracker-note {
        margin: 24px 0 0;
        padding: 14px 16px;
        border-radius: 12px;
        background: #FFF9F0;
        color: var(--a-text);
        font-size: 13.5px;
        line-height: 1.7;
    }

    .tracker-foot {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 16px;
    }

    /* =====================================
       RIWAYAT PESANAN
    ===================================== */

    .order-tabs {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 18px;
    }

    .order-tab {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 8px 14px;
        border: 1.5px solid #E3DDCF;
        border-radius: 999px;
        background: white;
        color: var(--a-muted);
        font-family: 'Inter', sans-serif;
        font-size: 12.5px;
        font-weight: 700;
        cursor: pointer;
        -webkit-tap-highlight-color: transparent;
        transition: background-color .25s var(--a-ease), color .25s var(--a-ease), border-color .25s var(--a-ease);
    }

    .order-tab small {
        min-width: 20px;
        padding: 2px 6px;
        border-radius: 999px;
        background: #F1EDE3;
        color: var(--a-navy);
        font-size: 11px;
        font-weight: 800;
        text-align: center;
    }

    .order-tab.active {
        border-color: var(--a-navy);
        background: var(--a-navy);
        color: white;
    }

    .order-tab.active small {
        background: rgba(255,255,255,.18);
        color: white;
    }

    @media (hover: hover) {
        .order-tab:not(.active):hover {
            border-color: var(--a-gold);
            color: var(--a-navy);
        }
    }

    .order-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .order-card {
        display: grid;
        grid-template-columns: 72px minmax(0, 1fr) auto;
        align-items: center;
        gap: 16px;
        padding: 16px;
        border: 1px solid #EEEAE2;
        border-radius: 14px;
        background: white;
        transition: border-color .3s var(--a-ease), box-shadow .3s var(--a-ease);
    }

    .order-card[hidden],
    .orders-filter-empty[hidden] { display: none; }

    @media (hover: hover) {
        .order-card:hover {
            border-color: #E5C88F;
            box-shadow: 0 8px 20px rgba(8,39,68,.06);
        }
    }

    .order-thumb {
        width: 72px;
        height: 72px;
        padding: 6px;
        border-radius: 12px;
        object-fit: contain;
        background: #ECE9E1;
    }

    .order-top {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px 10px;
        margin-bottom: 6px;
    }

    .order-number {
        color: var(--a-navy);
        font-size: 13px;
        font-weight: 800;
    }

    .order-product {
        margin: 0 0 4px;
        color: var(--a-navy);
        font-size: 15px;
        font-weight: 800;
        line-height: 1.35;
    }

    .order-meta {
        margin: 0;
        color: var(--a-muted);
        font-size: 12.5px;
    }

    .order-progress {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 4px;
        max-width: 220px;
        margin-top: 12px;
    }

    .op-seg {
        height: 4px;
        border-radius: 4px;
        background: #E9E4D8;
    }

    .op-seg.on { background: var(--a-gold); }

    .order-side {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 12px;
    }

    .order-total {
        color: var(--a-navy);
        font-family: 'Manrope', sans-serif;
        font-size: 16px;
        font-weight: 800;
        white-space: nowrap;
    }

    .order-actions {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        gap: 8px;
    }

    .orders-filter-empty,
    .empty-orders {
        padding: 36px 20px;
        border-radius: 14px;
        background: #F7F5EF;
        color: var(--a-muted);
        font-size: 14px;
        text-align: center;
    }

    .empty-orders {
        padding: 56px 20px;
        background: transparent;
    }

    .empty-orders .empty-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 76px;
        height: 76px;
        margin: 0 auto 18px;
        border-radius: 50%;
        background: #FFF3DC;
        color: #B87308;
    }

    .empty-orders h3 {
        margin: 0 0 8px;
        color: var(--a-navy);
        font-size: 19px;
        font-weight: 800;
    }

    .empty-orders p {
        margin: 0 auto 22px;
        max-width: 380px;
        line-height: 1.7;
    }

    .pagination-wrapper { margin-top: 22px; }

    .pagination-wrapper svg {
        display: inline-block;
        width: 20px;
        height: 20px;
    }

    /* =====================================
       NOTIFIKASI
    ===================================== */

    .notif-count {
        padding: 6px 12px;
        border-radius: 999px;
        background: #F5A623;
        color: #082744;
        font-size: 11.5px;
        font-weight: 800;
    }

    .notif-count.is-clear {
        background: #E7F4EC;
        color: #237344;
    }

    .notif-item {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 13px;
        padding: 14px;
        margin-bottom: 10px;
        border: 1px solid #EEEAE2;
        border-radius: 12px;
        background: white;
        transition: border-color .25s var(--a-ease);
    }

    .notif-item:last-child { margin-bottom: 0; }

    .notif-item.unread {
        border-color: #F5D99F;
        background: #FFF9ED;
    }

    .notif-item.unread::after {
        content: "";
        position: absolute;
        top: 14px;
        right: 14px;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #E53935;
    }

    .notif-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 38px;
        height: 38px;
        min-width: 38px;
        border-radius: 50%;
        background: #EEF1F4;
        color: #5B6775;
    }

    .notif-item.unread .notif-icon {
        background: var(--a-navy);
        color: var(--a-gold);
    }

    .notif-body {
        flex: 1;
        min-width: 0;
        padding-right: 12px;
    }

    .notif-body p {
        margin: 0 0 6px;
        color: var(--a-text);
        font-size: 13.5px;
        line-height: 1.6;
    }

    .notif-body small {
        color: var(--a-muted);
        font-size: 12px;
    }

    .notif-body form { margin: 8px 0 0; }

    .notif-link {
        padding: 0;
        border: 0;
        background: none;
        color: var(--a-amber);
        font-family: 'Inter', sans-serif;
        font-size: 12px;
        font-weight: 800;
        cursor: pointer;
        transition: color .2s ease;
    }

    .notif-link:hover { color: var(--a-navy); }

    .notif-empty {
        padding: 34px 16px;
        border-radius: 12px;
        background: #F7F5EF;
        color: var(--a-muted);
        font-size: 13.5px;
        line-height: 1.7;
        text-align: center;
    }

    .notif-empty .acc-ic {
        margin: 0 auto 10px;
        color: #B7B0A1;
    }

    /* =====================================
       BANTUAN
    ===================================== */

    .help-card {
        position: relative;
        overflow: hidden;
        padding: 26px;
        border-radius: 18px;
        background: linear-gradient(135deg, #082744, #0F3558);
        color: white;
    }

    .help-card::after {
        content: "";
        position: absolute;
        right: -60px;
        bottom: -80px;
        width: 200px;
        height: 200px;
        border: 1px solid rgba(245,166,35,.25);
        border-radius: 50%;
        pointer-events: none;
    }

    .help-card > * { position: relative; z-index: 1; }

    .help-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 44px;
        height: 44px;
        margin-bottom: 14px;
        border-radius: 12px;
        background: rgba(245,166,35,.18);
        color: var(--a-gold);
    }

    .help-card h2 {
        margin: 0 0 8px;
        color: white;
        font-size: 18px;
        font-weight: 800;
    }

    .help-card p {
        margin: 0 0 18px;
        color: #D6E0E9;
        font-size: 13.5px;
        line-height: 1.7;
    }

    /* =====================================
       REKOMENDASI
    ===================================== */

    .suggest-section { margin-top: 40px; }

    .suggest-head {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        gap: 14px;
        margin-bottom: 18px;
    }

    .suggest-head h2 {
        margin: 0;
        color: var(--a-navy);
        font-size: 21px;
        font-weight: 800;
    }

    .suggest-head a {
        color: var(--a-amber);
        font-size: 13px;
        font-weight: 800;
        white-space: nowrap;
        transition: color .25s ease;
    }

    .suggest-head a:hover { color: var(--a-navy); }

    .suggest-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 16px;
    }

    .suggest-card {
        position: relative;
        overflow: hidden;
        border-radius: 14px;
        background: white;
        box-shadow: 0 3px 12px rgba(8,39,68,.07);
        transition: transform .35s var(--a-ease), box-shadow .35s var(--a-ease);
    }

    .suggest-card:active { transform: scale(.985); }

    @media (hover: hover) {
        .suggest-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 26px rgba(8,39,68,.12);
        }
    }

    .suggest-image {
        height: 160px;
        background: #ECE9E1;
    }

    .suggest-image img {
        width: 100%;
        height: 100%;
        padding: 8px;
        object-fit: contain;
    }

    .suggest-info { padding: 14px 16px 16px; }

    .suggest-info a {
        display: block;
        color: var(--a-navy);
        font-size: 14px;
        font-weight: 800;
        line-height: 1.4;
    }

    /* Seluruh kartu bisa diklik */
    .suggest-info a::before {
        content: "";
        position: absolute;
        inset: 0;
    }

    .suggest-price {
        margin-top: 6px;
        color: var(--a-text);
        font-size: 13px;
        font-weight: 700;
    }

    /* =====================================
       RESPONSIVE
    ===================================== */

    @media (max-width: 1000px) {
        .account-grid,
        .account-grid.no-tracker {
            grid-template-columns: minmax(0, 1fr);
        }

        .account-grid {
            grid-template-areas:
                "tracker"
                "notif"
                "orders"
                "help";
        }

        .account-grid.no-tracker {
            grid-template-areas:
                "notif"
                "orders"
                "help";
        }

        .suggest-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    }

    @media (max-width: 700px) {
        .account-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }

        .acc-stat {
            gap: 12px;
            padding: 15px;
        }

        .acc-stat-icon {
            width: 38px;
            height: 38px;
            min-width: 38px;
        }

        .acc-stat strong { font-size: 23px; }

        .order-card {
            grid-template-columns: 60px minmax(0, 1fr);
            gap: 12px 14px;
        }

        .order-thumb {
            width: 60px;
            height: 60px;
        }

        .order-side {
            grid-column: 1 / -1;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            padding-top: 12px;
            border-top: 1px dashed #E9E4D8;
        }
    }

    @media (max-width: 550px) {
        .account-page { padding: 28px 5% 70px; }

        .account-hero {
            padding: 24px 20px;
            border-radius: 18px;
        }

        .hero-user { gap: 14px; }

        .hero-avatar {
            width: 58px;
            height: 58px;
            min-width: 58px;
            font-size: 21px;
        }

        .hero-user p { font-size: 12.5px; }

        .hero-actions {
            width: 100%;
        }

        .hero-actions > *,
        .hero-actions form {
            flex: 1;
        }

        .hero-actions .acc-btn {
            width: 100%;
            padding: 12px 14px;
        }

        .acc-card,
        .help-card { padding: 20px 18px; }

        .tracker-head {
            flex-direction: column;
            align-items: flex-start;
        }

        .t-label { font-size: 11px; }

        .t-dot {
            width: 34px;
            height: 34px;
        }

        .t-step::before { top: 16px; }

        .tracker-foot .acc-btn { flex: 1; }

        .order-actions {
            width: 100%;
            justify-content: stretch;
        }

        .order-actions .acc-btn { flex: 1; }

        .order-side { align-items: flex-start; }

        .suggest-grid { gap: 12px; }

        .suggest-image { height: 130px; }

        .suggest-info { padding: 12px; }

        .suggest-info a { font-size: 13px; }
    }

    @media (prefers-reduced-motion: reduce) {
        .t-step.is-current .t-dot { animation: none; }

        .suggest-card,
        .acc-btn { transition: none; }
    }
</style>

<div class="account-page">
    <div class="account-container">

        {{-- NOTIFIKASI SISTEM --}}
        @if(session('success'))
            <div class="account-alert success" role="status">
                {!! $icon('done', 20) !!}
                <span>{{ session('success') }}</span>
                <button type="button" data-dismiss aria-label="Tutup">{!! $icon('x', 16) !!}</button>
            </div>
        @endif

        @if(session('error'))
            <div class="account-alert error" role="alert">
                {!! $icon('alert', 20) !!}
                <span>{{ session('error') }}</span>
                <button type="button" data-dismiss aria-label="Tutup">{!! $icon('x', 16) !!}</button>
            </div>
        @endif

        {{-- HERO PROFIL --}}
        <section class="account-hero">

            <div class="hero-user">

                <div class="hero-avatar" aria-hidden="true">{{ $initials }}</div>

                <div>
                    <p class="hero-eyebrow">
                        Dashboard Customer
                        @if($memberSince)
                            · Anggota sejak {{ $memberSince }}
                        @endif
                    </p>
                    <h1>Halo, {{ $firstName }}!</h1>
                    <p>{{ $user->email }}</p>
                </div>

            </div>

            <div class="hero-actions">

                <a href="{{ route('catalog.index') }}" class="acc-btn acc-btn--gold">
                    Jelajahi Katalog {!! $icon('arrow', 16) !!}
                </a>

                <form action="{{ route('logout') }}" method="POST">
                    @csrf

                    <button type="submit" class="acc-btn acc-btn--ghost">
                        {!! $icon('logout', 16) !!} Keluar
                    </button>
                </form>

            </div>

        </section>

        {{-- STATISTIK PESANAN --}}
        <section class="account-stats">

            <div class="acc-stat">
                <span class="acc-stat-icon">{!! $icon('bag', 22) !!}</span>
                <div>
                    <span class="acc-stat-label">Total Pesanan</span>
                    <strong>{{ $stats['total'] ?? 0 }}</strong>
                </div>
            </div>

            <div class="acc-stat {{ ($stats['pending'] ?? 0) > 0 ? 'acc-stat--alert' : '' }}">
                <span class="acc-stat-icon">{!! $icon('clock', 22) !!}</span>
                <div>
                    <span class="acc-stat-label">Menunggu</span>
                    <strong>{{ $stats['pending'] ?? 0 }}</strong>
                </div>
            </div>

            <div class="acc-stat">
                <span class="acc-stat-icon">{!! $icon('progress', 22) !!}</span>
                <div>
                    <span class="acc-stat-label">Diproses</span>
                    <strong>{{ $stats['processing'] ?? 0 }}</strong>
                </div>
            </div>

            <div class="acc-stat">
                <span class="acc-stat-icon">{!! $icon('done', 22) !!}</span>
                <div>
                    <span class="acc-stat-label">Selesai</span>
                    <strong>{{ $stats['completed'] ?? 0 }}</strong>
                </div>
            </div>

        </section>

        <div class="account-grid {{ $activeOrder ? '' : 'no-tracker' }}">

            {{-- PELACAK PESANAN AKTIF --}}
            @if($activeOrder)

                @php
                    $activeKey  = $normalizeStatus($activeOrder->status);
                    $activeStep = $stepIndex[$activeKey] ?? 1;
                    $trackSteps = [
                        1 => ['Menunggu', 'clock'],
                        2 => ['Diproses', 'progress'],
                        3 => ['Dikirim', 'truck'],
                        4 => ['Selesai', 'done'],
                    ];
                @endphp

                <section class="acc-card tracker-card area-tracker">

                    <div class="tracker-head">

                        <div class="tracker-order">

                            <img
                                class="tracker-thumb"
                                src="{{ $orderImage($activeOrder) }}"
                                alt=""
                                width="56"
                                height="56"
                            >

                            <div>
                                <span class="tracker-eyebrow">Pesanan Aktif</span>
                                <h2>{{ $activeOrder->product->name ?? 'Produk tidak tersedia' }}</h2>
                                <p>No. {{ $activeOrder->order_number }}</p>
                            </div>

                        </div>

                        <span class="status {{ $statusClass($activeKey) }}">
                            {{ $statusLabel($activeKey) }}
                        </span>

                    </div>

                    <div class="tracker-steps">

                        @foreach($trackSteps as $number => $step)

                            <div class="t-step {{ $number < $activeStep ? 'is-done' : ($number === $activeStep ? 'is-current' : '') }}">
                                <span class="t-dot">
                                    @if($number < $activeStep)
                                        {!! $icon('check', 18) !!}
                                    @else
                                        {!! $icon($step[1], 18) !!}
                                    @endif
                                </span>
                                <span class="t-label">{{ $step[0] }}</span>
                            </div>

                        @endforeach

                    </div>

                    <p class="tracker-note">
                        {{ $statusNotes[$activeKey] ?? 'Pantau perkembangan pesanan Anda di halaman detail.' }}
                    </p>

                    <div class="tracker-foot">

                        <a
                            href="{{ route('account.orders.show', $activeOrder->id) }}"
                            class="acc-btn acc-btn--navy acc-btn--sm"
                        >
                            Lihat Detail Pesanan {!! $icon('arrow', 15) !!}
                        </a>

                        <a
                            href="{{ $waOrderUrl($activeOrder->order_number) }}"
                            class="acc-btn acc-btn--outline acc-btn--sm"
                            target="_blank"
                            rel="noopener"
                        >
                            {!! $waIcon !!} Tanya via WhatsApp
                        </a>

                    </div>

                </section>

            @endif


            {{-- NOTIFIKASI PESANAN --}}
            <section class="acc-card area-notif" id="notifications">

                <div class="acc-card-head">

                    <h2>Notifikasi Pesanan</h2>

                    @if($unreadCount > 0)
                        <span class="notif-count">{{ $unreadCount }} Belum Dibaca</span>
                    @else
                        <span class="notif-count is-clear">Semua Terbaca</span>
                    @endif

                </div>

                @if($notifications->count() > 0)

                    @foreach($notifications as $notification)

                        <div class="notif-item {{ $notification->read_at ? '' : 'unread' }}">

                            <span class="notif-icon">{!! $icon('bell', 18) !!}</span>

                            <div class="notif-body">

                                <p>
                                    {{ $notification->data['message'] ?? 'Ada pembaruan pesanan Anda.' }}
                                </p>

                                <small title="{{ $notification->created_at->format('d/m/Y H:i') }}">
                                    {{ $notification->created_at->locale('id')->diffForHumans() }}
                                </small>

                                @if(!empty($notification->data['order_id']))

                                    <form
                                        action="{{ route('account.notifications.read', $notification->id) }}"
                                        method="POST"
                                    >
                                        @csrf

                                        <button type="submit" class="notif-link">
                                            Lihat Detail Pesanan →
                                        </button>
                                    </form>

                                @endif

                            </div>

                        </div>

                    @endforeach

                @else

                    <div class="notif-empty">
                        {!! $icon('bell', 30) !!}
                        Belum ada notifikasi.<br>
                        Perubahan status pesanan akan muncul di sini.
                    </div>

                @endif

            </section>


            {{-- RIWAYAT PESANAN --}}
            <section class="acc-card area-orders" id="orders">

                <div class="acc-card-head">
                    <h2>Riwayat Pesanan Saya</h2>
                </div>

                @if($orders->count() > 0)

                    {{-- Filter status (berlaku untuk pesanan yang tampil di halaman ini) --}}
                    @if($statusCounts->count() > 1)

                        <div class="order-tabs" role="group" aria-label="Filter status pesanan">

                            <button type="button" class="order-tab active" data-filter="semua" aria-pressed="true">
                                Semua <small>{{ $orderItems->count() }}</small>
                            </button>

                            @foreach(array_keys($statusLabels) as $statusKey)
                                @if(($statusCounts[$statusKey] ?? 0) > 0)
                                    <button type="button" class="order-tab" data-filter="{{ $statusKey }}" aria-pressed="false">
                                        {{ $statusLabels[$statusKey] }} <small>{{ $statusCounts[$statusKey] }}</small>
                                    </button>
                                @endif
                            @endforeach

                        </div>

                    @endif

                    <div class="order-list">

                        @foreach($orderItems as $order)

                            @php
                                $key  = $normalizeStatus($order->status);
                                $step = $stepIndex[$key] ?? 0;
                            @endphp

                            <article class="order-card" data-status="{{ $key }}">

                                <img
                                    class="order-thumb"
                                    src="{{ $orderImage($order) }}"
                                    alt=""
                                    width="72"
                                    height="72"
                                    loading="lazy"
                                    decoding="async"
                                >

                                <div class="order-main">

                                    <div class="order-top">
                                        <span class="order-number">{{ $order->order_number }}</span>
                                        <span class="status {{ $statusClass($key) }}">{{ $statusLabel($key) }}</span>
                                    </div>

                                    <h3 class="order-product">
                                        {{ $order->product->name ?? 'Produk tidak tersedia' }}
                                    </h3>

                                    <p class="order-meta">
                                        {{ $order->quantity }} item · {{ $order->created_at->format('d/m/Y') }}
                                    </p>

                                    @if($step > 0)
                                        <div class="order-progress" aria-hidden="true">
                                            @for($i = 1; $i <= 4; $i++)
                                                <span class="op-seg {{ $i <= $step ? 'on' : '' }}"></span>
                                            @endfor
                                        </div>
                                    @endif

                                </div>

                                <div class="order-side">

                                    <div class="order-total">
                                        Rp {{ number_format($order->total_price, 0, ',', '.') }}
                                    </div>

                                    <div class="order-actions">

                                        <a
                                            href="{{ route('account.orders.show', $order->id) }}"
                                            class="acc-btn acc-btn--navy acc-btn--sm"
                                        >
                                            Detail Pesanan
                                        </a>

                                        <a
                                            href="{{ $waOrderUrl($order->order_number) }}"
                                            class="acc-btn acc-btn--outline acc-btn--sm"
                                            target="_blank"
                                            rel="noopener"
                                            aria-label="Tanya pesanan {{ $order->order_number }} via WhatsApp"
                                        >
                                            {!! $waIcon !!} Tanya
                                        </a>

                                    </div>

                                </div>

                            </article>

                        @endforeach

                        <div class="orders-filter-empty" id="ordersFilterEmpty" hidden>
                            Tidak ada pesanan dengan status ini di halaman ini.
                        </div>

                    </div>

                    @if(method_exists($orders, 'hasPages') && $orders->hasPages())
                        <div class="pagination-wrapper">
                            {{ $orders->links() }}
                        </div>
                    @endif

                @else

                    <div class="empty-orders">

                        <div class="empty-icon">{!! $icon('bag', 32) !!}</div>

                        <h3>Belum Ada Pesanan</h3>

                        <p>
                            Pesanan yang Anda buat nantinya akan muncul
                            di halaman ini lengkap dengan status pengerjaannya.
                        </p>

                        <a href="{{ route('catalog.index') }}" class="acc-btn acc-btn--gold">
                            Jelajahi Katalog {!! $icon('arrow', 16) !!}
                        </a>

                    </div>

                @endif

            </section>


            {{-- BANTUAN --}}
            <aside class="help-card area-help">

                <div class="help-icon">{!! $icon('support', 22) !!}</div>

                <h2>Butuh Bantuan?</h2>

                <p>
                    Tim TERRAWOOD siap membantu pertanyaan seputar pesanan,
                    pengiriman, atau produk custom.
                </p>

                <a href="{{ $waHelpUrl }}" class="acc-btn acc-btn--wa" target="_blank" rel="noopener">
                    {!! $waIcon !!} Chat via WhatsApp
                </a>

            </aside>

        </div>


        {{-- REKOMENDASI PRODUK --}}
        @if($suggestions->isNotEmpty())

            <section class="suggest-section">

                <div class="suggest-head">

                    <h2>Mungkin Anda Suka</h2>

                    <a href="{{ route('catalog.index') }}">Lihat Katalog →</a>

                </div>

                <div class="suggest-grid">

                    @foreach($suggestions as $product)

                        <div class="suggest-card">

                            <div class="suggest-image">
                                <img
                                    src="{{ $product->image ? asset('storage/' . ltrim($product->image, '/')) : $fallbackImage }}"
                                    alt="{{ $product->name }}"
                                    width="400"
                                    height="300"
                                    loading="lazy"
                                    decoding="async"
                                >
                            </div>

                            <div class="suggest-info">

                                <a href="{{ route('catalog.show', $product->slug) }}">
                                    {{ $product->name }}
                                </a>

                                <div class="suggest-price">
                                    @if(!empty($product->price))
                                        Rp {{ number_format($product->price, 0, ',', '.') }}
                                    @else
                                        Hubungi kami
                                    @endif
                                </div>

                            </div>

                        </div>

                    @endforeach

                </div>

            </section>

        @endif

    </div>
</div>

@include('partials.footer')

<script>
document.addEventListener('DOMContentLoaded', function () {

    /* Tutup pesan sukses / error */

    document.querySelectorAll('[data-dismiss]').forEach(function (button) {

        button.addEventListener('click', function () {
            const alertBox = button.closest('.account-alert');

            if (alertBox) alertBox.remove();
        });

    });


    /* Filter status pesanan */

    const tabs = document.querySelectorAll('.order-tab');
    const cards = document.querySelectorAll('.order-card');
    const emptyMessage = document.getElementById('ordersFilterEmpty');

    if (!tabs.length) return;

    function applyFilter(filter) {

        let visible = 0;

        cards.forEach(function (card) {

            const show = filter === 'semua' || card.dataset.status === filter;

            card.hidden = !show;

            if (show) visible++;

        });

        tabs.forEach(function (tab) {

            const isActive = tab.dataset.filter === filter;

            tab.classList.toggle('active', isActive);
            tab.setAttribute('aria-pressed', isActive ? 'true' : 'false');

        });

        if (emptyMessage) {
            emptyMessage.hidden = visible !== 0;
        }

    }

    tabs.forEach(function (tab) {

        tab.addEventListener('click', function () {
            applyFilter(tab.dataset.filter);
        });

    });

});
</script>

@endsection